import dotenv from "dotenv";
dotenv.config();
import pg from "pg";
const { Pool } = pg;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const EXTENSIVE_ARTISTS = [
  // ================= 1. عمالقة الطرب والزمن الجميل =================
  { name: "Umm Kulthum", nameAr: "أم كلثوم", queries: ["أم كلثوم أنت عمري", "أم كلثوم ألف ليلة", "أم كلثوم سيرة الحب", "أم كلثوم فكروني", "Umm Kulthum Classics"], genre: "طرب أصيل", cat: "tarab", lang: "arabic", bio: "كوكب الشرق وسيدة الغناء العربي، أيقونة الطرب الخالدة.", listeners: "2.4M" },
  { name: "Abdel Halim Hafez", nameAr: "عبد الحليم حافظ", queries: ["عبد الحليم حافظ قارئة الفنجان", "عبد الحليم حافظ سواح", "عبد الحليم حافظ جانا الهوى", "Abdel Halim Hafez Hits"], genre: "طرب ورومانسي", cat: "tarab", lang: "arabic", bio: "العندليب الأسمر، صاحب الصوت الشجي وأعظم أغاني الحب والسينما المصرية.", listeners: "3.1M" },
  { name: "Fairuz", nameAr: "فيروز", queries: ["فيروز كيفك إنت", "فيروز سألوني الناس", "فيروز نسم علينا الهوا", "فيروزيات الصباح", "Fairouz Best Of"], genre: "طرب كلاسيكي", cat: "tarab", lang: "arabic", bio: "جارة القمر وصوت لبنان الساحر، رفيقة الصباحات وأغاني الوطن والحب.", listeners: "4.5M" },
  { name: "Warda", nameAr: "وردة الجزائرية", queries: ["وردة بتونس بيك", "وردة حرمت أحبك", "وردة في يوم وليلة", "وردة أكدب عليك"], genre: "طرب رومانسي", cat: "tarab", lang: "arabic", bio: "أميرة الطرب العربي، صاحبة الحنجرة الذهبية وأعذب الأغاني العاطفية.", listeners: "2.8M" },
  { name: "Farid El Atrash", nameAr: "فريد الأطرش", queries: ["فريد الأطرش جميل جمال", "فريد الأطرش أول همسة", "فريد الأطرش حكاية غرامي"], genre: "طرب وموسيقى شرقية", cat: "tarab", lang: "arabic", bio: "ملك العود وموسيقار الأجيال، أثرى الموسيقى العربية بروائع الطرب.", listeners: "1.8M" },
  { name: "Mohamed Abdel Wahab", nameAr: "محمد عبد الوهاب", queries: ["محمد عبد الوهاب مضناك", "محمد عبد الوهاب كليوباترا", "عبد الوهاب أهواك"], genre: "طرب وموسيقى كلاسيكية", cat: "tarab", lang: "arabic", bio: "موسيقار الأجيال ورائد التطوير والتجديد في الموسيقى العربية الحديثة.", listeners: "1.5M" },
  { name: "George Wassouf", nameAr: "جورج وسوف", queries: ["جورج وسوف طبيب جراح", "جورج وسوف كلام الناس", "جورج وسوف سلف ودين", "جورج وسوف الهوى سلطان"], genre: "طرب شعبي حديث", cat: "tarab", lang: "arabic", bio: "سلطان الطرب، أحد أعظم الأصوات الطربية ذات الجماهيرية الجارفة في العالم العربي.", listeners: "3.7M" },
  { name: "Sabah Fakhri", nameAr: "صباح فخري", queries: ["صباح فخري خمرة الحب", "صباح فخري قل للمليحة", "صباح فخري قدود حلبية"], genre: "قدود حلبية وموشحات", cat: "tarab", lang: "arabic", bio: "ملك القدود الحلبية والموشحات الأندلسية، أحد عمالقة الغناء الشرقي.", listeners: "900K" },
  { name: "Mayada El Hennawy", nameAr: "ميادة الحناوي", queries: ["ميادة الحناوي أنا بعشقك", "ميادة الحناوي كان يا ما كان", "ميادة الحناوي نعمة النسيان"], genre: "طرب كلاسيكي", cat: "tarab", lang: "arabic", bio: "مطربة الجيل، تميزت بأغانيها الطربية الطويلة الملحنة من بليغ حمدي والموجي.", listeners: "1.1M" },
  { name: "Talal Maddah", nameAr: "طلال مداح", queries: ["طلال مداح مقادير", "طلال مداح زمان الصمت", "طلال مداح ظالم ولكن"], genre: "طرب أصيل وصوت الأرض", cat: "tarab", lang: "arabic", bio: "صوت الأرض والقيثارة الشرقية، رائد الموسيقى والتطوير الغنائي السعودي.", listeners: "2.3M" },
  { name: "Sayed Mekawy", nameAr: "سيد مكاوي", queries: ["سيد مكاوي أوقاتي بتحلو", "سيد مكاوي الليلة الكبيرة", "سيد مكاوي المسحراتي"], genre: "طرب وفولكلور مصري أصيل", cat: "tarab", lang: "arabic", bio: "شيخ الملحنين ومبدع «الليلة الكبيرة» و«أوقاتي بتحلو».", listeners: "1.1M" },
  { name: "Najat Al Saghira", nameAr: "نجاة الصغيرة", queries: ["نجاة الصغيرة عيون القلب", "نجاة الصغيرة أما براوة", "نجاة الصغيرة ساكن قصادي"], genre: "طرب رومانسي هادئ", cat: "tarab", lang: "arabic", bio: "صاحبة الصوت المخملي الهادئ وأعذب القصائد والألحان الرومانسية.", listeners: "1.4M" },
  { name: "Shadia", nameAr: "شادية", queries: ["شادية يا حبيبتي يا مصر", "شادية إن راح منك يا عين", "شادية مخاصمني بقالو مدة"], genre: "طرب وبوب كلاسيكي", cat: "tarab", lang: "arabic", bio: "دلوعة السينما المصرية وصوت مصر المحبوب في أغاني الفرح والوطن والدراما.", listeners: "1.9M" },
  { name: "Sabah", nameAr: "صباح (الشحرورة)", queries: ["صباح ساعات ساعات", "صباح عاشقة وغلبانة", "صباح يانا يانا"], genre: "طرب واستعراضي لبناني", cat: "tarab", lang: "arabic", bio: "الشحرورة أسطورة الأغنية اللبنانية والمصرية.", listeners: "1.3M" },
  { name: "Mohamed El Helw", nameAr: "محمد الحلو", queries: ["محمد الحلو زيزينيا", "محمد الحلو ليالي الحلمية", "محمد الحلو عراف"], genre: "طرب وتترات درامية", cat: "tarab", lang: "arabic", bio: "صوت الدراما المصرية الأصيل ومبدع تترات «ليالي الحلمية» و«زيزينيا».", listeners: "1.6M" },
  { name: "Ali El Haggar", nameAr: "علي الحجار", queries: ["علي الحجار بوابة الحلواني", "علي الحجار زي الهوى", "علي الحجار مسألة مبدأ", "علي الحجار عارفة"], genre: "طرب وأغاني تترات ومسلسلات", cat: "tarab", lang: "arabic", bio: "صوت الدراما المصرية وأحد أعظم الأصوات الطربية الأصيلة.", listeners: "1.8M" },
  { name: "Medhat Saleh", nameAr: "مدحت صالح", queries: ["مدحت صالح كوكب تاني", "مدحت صالح المليونيرات", "مدحت صالح حبيبي يا عاشق", "مدحت صالح تترات"], genre: "طرب وبوب مصري أصيل", cat: "tarab", lang: "arabic", bio: "صاحب الحنجرة القوية والإحساس العالي في الأغاني الدرامية والطربية.", listeners: "2.1M" },

  // ================= 2. نجوم البوب والتسعينات والرومانسية في مصر =================
  { name: "Amr Diab", nameAr: "عمرو دياب", queries: ["عمرو دياب تملي معاك", "عمرو دياب نور العين", "عمرو دياب قمرين", "عمرو دياب وماله", "عمرو دياب مكانك", "Amr Diab Greatest Hits"], genre: "بوب عربي وميديتيرانيان", cat: "pop", lang: "arabic", bio: "الهضبة، أسطورة البوب العربي لأكثر من 4 عقود وصاحب الجوائز العالمية.", listeners: "9.5M" },
  { name: "Tamer Hosny", nameAr: "تامر حسني", queries: ["تامر حسني كل مرة", "تامر حسني هرمون السعادة", "تامر حسني عيش بشوقك", "تامر حسني سي السيد", "Tamer Hosny Album"], genre: "بوب ورومانسي", cat: "romantic", lang: "arabic", bio: "نجم الجيل، مغني وممثل وكاتب أغاني حقق نجاحات جماهيرية كبرى.", listeners: "7.1M" },
  { name: "Mohamed Hamaki", nameAr: "محمد حماقي", queries: ["محمد حماقي أحلى حاجة فيكي", "محمد حماقي يا ستار", "محمد حماقي ما بلاش", "محمد حماقي هو ده حبيبى", "Hamaki Album"], genre: "بوب مصري معاصر", cat: "pop", lang: "arabic", bio: "نجم البوب المصري المعاصر وأحد أكثر الأصوات تميزاً في الحفلات.", listeners: "5.3M" },
  { name: "Sherine", nameAr: "شيرين عبد الوهاب", queries: ["شيرين مشاعر", "شيرين كلي ملكك", "شيرين صبري قليل", "شيرين جرح تاني", "شيرين حبه جنة", "Sherine Hits"], genre: "رومانسي وإحساس", cat: "romantic", lang: "arabic", bio: "ملكة الإحساس، صاحبة الصوت الدافئ والتعبيرات الصوتية الفريدة.", listeners: "6.2M" },
  { name: "Angham", nameAr: "أنغام", queries: ["أنغام سيدي وصالك", "أنغام اكتبلك تعهد", "أنغام ونفضل نرقص", "أنغام ياريتك فاهمني"], genre: "طربي حديث ورومانسي", cat: "romantic", lang: "arabic", bio: "صوت مصر، واحدة من أرقى المطربات العربيات أداءً وإحساساً.", listeners: "3.9M" },
  { name: "Bahaa Sultan", nameAr: "بهاء سلطان", queries: ["بهاء سلطان قلبك يا حول الله", "بهاء سلطان الواد قلبه بيوجعه", "بهاء سلطان تعالى أدلعك", "بهاء سلطان قوم اقف"], genre: "بوب وشعبي راقي", cat: "pop", lang: "arabic", bio: "صاحب الحنجرة الذهبية والأداء الصادق والأغاني التي لا تُنسى.", listeners: "4.2M" },
  { name: "Tamer Ashour", nameAr: "تامر عاشور", queries: ["تامر عاشور هيجيلي موجوع", "تامر عاشور كلموها عني", "تامر عاشور تسلم", "تامر عاشور عشت معاك حكايات"], genre: "دراما ورومانسي حزين", cat: "romantic", lang: "arabic", bio: "سفير الأحزان وأستاذ الألحان الدرامية والمشاعر الصادقة المؤثرة.", listeners: "4.5M" },
  { name: "Ramy Sabry", nameAr: "رامي صبري", queries: ["رامي صبري غمضت عيني", "رامي صبري كلمة", "رامي صبري حياتي مش تمام", "رامي صبري يمكن خير"], genre: "بوب ورومانسي", cat: "romantic", lang: "arabic", bio: "مغني وملحن مصري متميز بأغاني الدراما والحب العصرية.", listeners: "3.4M" },
  { name: "Ramy Gamal", nameAr: "رامي جمال", queries: ["رامي جمال سقف", "رامي جمال اتفضل امشي", "رامي جمال فتره مش سهله"], genre: "بوب وملحن رومانسي", cat: "romantic", lang: "arabic", bio: "ملحن ومطرب مصري قدّم عشرات الهيتات لكبار نجوم الوطن العربي.", listeners: "2.9M" },
  { name: "Mohamed Mounir", nameAr: "محمد منير", queries: ["محمد منير الليلة يا سمرا", "محمد منير علي صوتك", "محمد منير شبابيك", "محمد منير يونس", "محمد منير سو يا سو"], genre: "موسيقى نوبية وبوب بديل", cat: "world", lang: "arabic", bio: "الكينج محمد منير، صاحب الصوت الفريد والدمج بين التراث والموسيقى العالمية.", listeners: "3.8M" },
  { name: "Mohamed Fouad", nameAr: "محمد فؤاد", queries: ["محمد فؤاد الحب الحقيقي", "محمد فؤاد حيران", "محمد فؤاد كمننا", "محمد فؤاد فاكرك يا ناسيني", "محمد فؤاد طمني عليك"], genre: "بوب ورومانسي التسعينات", cat: "pop", lang: "arabic", bio: "ابن البلد ونجم جيل التسعينات الذهبي صاحب «الحب الحقيقي» و«حيران».", listeners: "3.9M" },
  { name: "Ehab Tawfik", nameAr: "إيهاب توفيق", queries: ["إيهاب توفيق سحراني", "إيهاب توفيق الله عليك يا سيدي", "إيهاب توفيق تترجى فيا", "إيهاب توفيق عامل عاملة"], genre: "بوب التسعينات الكلاسيكي", cat: "pop", lang: "arabic", bio: "أحد أبرز نجوم التسعينات وأصحاب الأغاني الرومانسية والشعبية الخالدة.", listeners: "2.8M" },
  { name: "Moustafa Amar", nameAr: "مصطفى قمر", queries: ["مصطفى قمر سكة العاشقين", "مصطفى قمر الليلة دوب", "مصطفى قمر السود عيونه", "مصطفى قمر منايا"], genre: "بوب وجيتار رومانسي", cat: "pop", lang: "arabic", bio: "نجم البوب السكندري وعازف الجيتار وصاحب أنجح ألبومات البوب في التسعينات.", listeners: "2.2M" },
  { name: "Hamid El Shaeri", nameAr: "حميد الشاعري", queries: ["حميد الشاعري عيني", "حميد الشاعري جلجلي", "حميد الشاعري روح السمارة"], genre: "موسيقى الجيل والبوب", cat: "pop", lang: "arabic", bio: "الكابو وصانع نهضة موسيقى الجيل والبوب العربي الحديث في التسعينات.", listeners: "1.7M" },
  { name: "Hisham Abbas", nameAr: "هشام عباس", queries: ["هشام عباس حبيبي ده", "هشام عباس زمان وأنا صغير", "هشام عباس حلال عليك"], genre: "بوب عربي مرح وفلكلوري", cat: "pop", lang: "arabic", bio: "صاحب الأغاني الإيقاعية المبهجة والدمج بين البوب المصري والشرقي.", listeners: "1.9M" },
  { name: "Hany Shaker", nameAr: "هاني شاكر", queries: ["هاني شاكر لسه بتسألي", "هاني شاكر علي الضحكاية", "هاني شاكر بحبك أنا", "هاني شاكر حكاية كل عاشق"], genre: "طرب ورومانسي مصري", cat: "romantic", lang: "arabic", bio: "أمير الغناء العربي، صاحب الصوت الشجي والأغاني العاطفية الراقية.", listeners: "2.6M" },
  { name: "Haitham Shaker", nameAr: "هيثم شاكر", queries: ["هيثم شاكر أحلف بالله", "هيثم شاكر خليك جنبي", "هيثم شاكر كنت مداويني"], genre: "رومانسي وبوب مصري", cat: "romantic", lang: "arabic", bio: "صاحب الصوت الشجي وأغاني «خليك جنبي» و«أحلف بالله».", listeners: "2.4M" },
  { name: "Khaled Selim", nameAr: "خالد سليم", queries: ["خالد سليم بلاش الملامة", "خالد سليم عالم تاني", "خالد سليم حلم عمري"], genre: "طرب وبوب مصري", cat: "pop", lang: "arabic", bio: "صاحب الحنجرة القوية والأغاني السينمائية والرومانسية.", listeners: "2.2M" },
  { name: "Khaled Agag", nameAr: "خالد عجاج", queries: ["خالد عجاج شكرا", "خالد عجاج ليه يا دنيا", "خالد عجاج وحشتني"], genre: "شعبي وبوب درامي", cat: "shaabi", lang: "arabic", bio: "صاحب الصوت الباكي وأشهر الأغاني الدرامية والشعبية في التسعينات.", listeners: "2.1M" },
  { name: "Mohamed Mohie", nameAr: "محمد محيي", queries: ["محمد محيي اتخنقت", "محمد محيي قادر وتعملها", "محمد محيي مظلوم", "محمد محيي ليه بيفكروني"], genre: "دراما وبوب حزين", cat: "romantic", lang: "arabic", bio: "أستاذ الدراما والشجن المصري وصاحب الأغاني العاطفية الأكثر تأثيراً.", listeners: "2.8M" },
  { name: "Amer Mounib", nameAr: "عامر منيب", queries: ["عامر منيب شوق وحنين", "عامر منيب فاكر", "عامر منيب أيام وليالي"], genre: "بوب ورومانسي هادئ", cat: "romantic", lang: "arabic", bio: "صاحب الصوت الرقيق والمشاعر العذبة وأجمل أغاني الحب في الألفينات.", listeners: "2.3M" },
  { name: "Hamada Helal", nameAr: "حمادة هلال", queries: ["حمادة هلال دايما دموع", "حمادة هلال كل ما أفكر فيك", "حمادة هلال مش هقول"], genre: "بوب ودراما وأغاني أفلام", cat: "pop", lang: "arabic", bio: "نجم البوب والدراما الشعبية المصرية صاحب «دايما دموع» و«المداح».", listeners: "3.7M" },
  { name: "Ahmed Batshan", nameAr: "أحمد بتشان", queries: ["أحمد بتشان بعد غيابه", "أحمد بتشان فيك العبر", "أحمد بتشان خلصت خلاص"], genre: "بوب ودراما شابة", cat: "romantic", lang: "arabic", bio: "صوت الدراما المصرية القوي وصاحب الأغاني العاطفية الناجحة كـ «بعد غيابه».", listeners: "3.1M" },
  { name: "Mohamed El Sharnouby", nameAr: "محمد الشرنوبي", queries: ["محمد الشرنوبي النفسية", "محمد الشرنوبي فاكر زمان"], genre: "بوب وطرب مصري حديث", cat: "pop", lang: "arabic", bio: "نجم الغناء والتمثيل المصري الشاب صاحب الصوت الدافئ.", listeners: "2.2M" },
  { name: "Wama", nameAr: "فريق واما", queries: ["واما يا ليل", "واما رايحة جاية", "واما مشوار طويل"], genre: "بوب وهارموني مصري", cat: "pop", lang: "arabic", bio: "أشهر فرقة بوب وهارموني شبابي مصري ضمت أحمد فهمي ونادر حمدي.", listeners: "2.6M" },
  { name: "Jannat", nameAr: "جنات", queries: ["جنات حب جامد", "جنات بحبك", "جنات عايشني أكتر"], genre: "رومانسي وبوب مصري مغربي", cat: "romantic", lang: "arabic", bio: "صاحبة الصوت الدافئ والرقيق وأشهر الأغاني الرومانسية.", listeners: "2.7M" },
  { name: "Carmen Soliman", nameAr: "كارمن سليمان", queries: ["كارمن سليمان لينا رقصة", "كارمن سليمان يا جمالك"], genre: "بوب وطرب حديث", cat: "pop", lang: "arabic", bio: "نجمة الطرب والبوب المصري الشابة وصاحبة الصوت النقي الحساس.", listeners: "2.2M" },
  { name: "Ahmed Gamal", nameAr: "أحمد جمال", queries: ["أحمد جمال اضحكي", "أحمد جمال قصاد عيوني"], genre: "بوب وطرب رومانسي", cat: "romantic", lang: "arabic", bio: "مطرب وملحن مصري متميز بأغاني المشاعر الصادقة والأداء الطربي.", listeners: "1.9M" },
  { name: "Loai", nameAr: "لؤي", queries: ["لؤي آه يا عيني يا ليلي", "لؤي واحد من الناس"], genre: "رومانسي ودراما", cat: "romantic", lang: "arabic", bio: "صاحب أغنية «آه يا عيني يا ليلي» وأجمل الأغاني الرومانسية الهادئة.", listeners: "1.6M" },
  { name: "Mahmoud El Esseily", nameAr: "محمود العسيلي", queries: ["محمود العسيلي دوم دوم", "محمود العسيلي انت تقدر", "محمود العسيلي تررم"], genre: "بوب مبتكر وموسيقى مستقلة", cat: "pop", lang: "arabic", bio: "مغني وملحن صاحب طابع فني عصري وأغاني صيفية ورومانسية مميزة.", listeners: "3.1M" },
  { name: "Amr Mostafa", nameAr: "عمرو مصطفى", queries: ["عمرو مصطفى إلا أنا", "عمرو مصطفى سيبوه", "عمرو مصطفى سلام سلام"], genre: "بوب وألحان سريعة", cat: "pop", lang: "arabic", bio: "الموسيقار والملحن المصري العبقري صانع مئات الهيتات العربية.", listeners: "2.7M" },

  // ================= 3. الفرق المصرية والموسيقى البديلة والترند =================
  { name: "Cairokee", nameAr: "كايروكي", queries: ["كايروكي روما", "كايروكي أنا نجم", "كايروكي ساموراي", "كايروكي تلك قضية", "كايروكي بسرح وأتوه", "Cairokee Hits"], genre: "روك عربي وموسيقى بديلة", cat: "rock", lang: "arabic", bio: "أشهر فرقة روك وموسيقى بديلة في الوطن العربي، صوت الشباب وأغاني الواقع.", listeners: "5.6M" },
  { name: "Hamza Namira", nameAr: "حمزة نمرة", queries: ["حمزة نمرة فاضي شوية", "حمزة نمرة رياح الحياة", "حمزة نمرة يا مظلوم", "حمزة نمرة داري يا قلبي", "Hamza Namira Album"], genre: "بوب بديل وتراث متجدد", cat: "pop", lang: "arabic", bio: "مجدد التراث وصانع الأغاني الإنسانية والاجتماعية التي حصدت مليارات المشاهدات.", listeners: "4.9M" },
  { name: "Massar Egbari", nameAr: "مسار إجباري", queries: ["مسار إجباري شيروفوبيا", "مسار إجباري تقع وتقوم", "مسار إجباري نهايات الحكاوي"], genre: "روك وجاز بديل سكندري", cat: "rock", lang: "arabic", bio: "فرقة سكندرية متميزة تمزج الروك والموسيقى الشرقية المعاصرة.", listeners: "2.8M" },
  { name: "Sharmoofers", nameAr: "شارموفرز", queries: ["شارموفرز 5 سنتي", "شارموفرز حزينة ليه يا زهرة", "شارموفرز إيزي ماني"], genre: "ريجي وإندي وبوب مبهج", cat: "world", lang: "arabic", bio: "أشهر فرقة ريجي وموسيقى مبهجة بروح مصرية معاصرة وطاقة إيجابية عالية.", listeners: "2.2M" },
  { name: "Tul8te", nameAr: "توليت", queries: ["توليت حبيبي ليه", "توليت عينيكي", "توليت ليالي", "توليت تيجي أعدي عليكي"], genre: "ريترو بوب وبوب بديل", cat: "pop", lang: "arabic", bio: "نجم البوب الغامض صاحب الطابع الموسيقي المستوحى من نوستالجيا التسعينات والألفينات.", listeners: "3.5M" },
  { name: "Al Shami", nameAr: "الشامي", queries: ["الشامي يا ليل ويالعين", "الشامي صبرا", "الشامي وين", "الشامي خدني"], genre: "بوب شامي وترند معاصر", cat: "pop", lang: "arabic", bio: "الظاهرة الفنية الشابة وصاحب الأغاني التي تصدرت قوائم الاستماع في الشرق الأوسط.", listeners: "6.3M" },
  { name: "Siilawy", nameAr: "سيلاوي", queries: ["سيلاوي لما تكوني", "سيلاوي عشانك", "سيلاوي قدام الكل", "سيلاوي شايف طيفك"], genre: "بوب ورومانسي بديل", cat: "romantic", lang: "arabic", bio: "مغني وكاتب أغاني أردني حققت أغانيه العاطفية انتشاراً واسعاً بين فئة الشباب.", listeners: "4.2M" },
  { name: "Big Sam", nameAr: "بيج سام", queries: ["بيج سام بتهون", "بيج سام ما بتهون", "بيج سام يا قمر"], genre: "هيب هوب وبوب عاطفي", cat: "rap", lang: "arabic", bio: "مغني ورابر فلسطيني تميز بالأغاني العاطفية ذات العمق والكلمات المؤثرة.", listeners: "3.1M" },

  // ================= 4. الشعبي والمهرجانات المصرية =================
  { name: "Ahmed Saad", nameAr: "أحمد سعد", queries: ["أحمد سعد وسع وسع", "أحمد سعد اختياراتي", "أحمد سعد إيه اليوم الحلو ده", "أحمد سعد عليكي عيون", "أحمد سعد يا عراف"], genre: "بوب وشعبي ودراما مصرية", cat: "pop", lang: "arabic", bio: "نجم البوب والدراما الشعبية المصرية وصاحب أعلى هيتات ترند في السنوات الأخيرة.", listeners: "6.9M" },
  { name: "Ruby", nameAr: "روبي", queries: ["روبي حتة تانية", "روبي نمت ننه", "روبي ليه بيداري كدا", "روبي 3 ساعات متواصلة", "روبي قلبي بلاستيك"], genre: "بوب واستعراضي مصري", cat: "pop", lang: "arabic", bio: "نجمة البوب والاستعراض المصري صاحبة أشهر هيتات الرقص والفرح.", listeners: "4.8M" },
  { name: "Mohamed Ramadan", nameAr: "محمد رمضان", queries: ["محمد رمضان نمبر وان", "محمد رمضان مافيا", "محمد رمضان يا حبيبي", "محمد رمضان إنساي", "محمد رمضان ثابت"], genre: "بوب وتراب واستعراضي", cat: "pop", lang: "arabic", bio: "نمبر وان، النجم الاستعراضي وصاحب الأغاني والشو الحماسي الأكثر مشاهدة.", listeners: "6.5M" },
  { name: "Ahmed Adaweya", nameAr: "أحمد عدوية", queries: ["أحمد عدوية زحمة يا دنيا زحمة", "أحمد عدوية بنت السلطان", "أحمد عدوية السح الدح إمبو"], genre: "شعبي أصيل", cat: "shaabi", lang: "arabic", bio: "أسطورة الأغنية الشعبية المصرية ورائد المواويل الشعبية.", listeners: "1.2M" },
  { name: "Hakim", nameAr: "حكيم", queries: ["حكيم حلاوة روح", "حكيم السلام عليكم", "حكيم آه يا قلبي", "حكيم ولا واحد ولا مية"], genre: "شعبي استعراضي", cat: "shaabi", lang: "arabic", bio: "نجم الأغنية الشعبية الراقصة وسفير الفرح والأفراح العربية.", listeners: "2.5M" },
  { name: "Abdel Baset Hamouda", nameAr: "عبد الباسط حمودة", queries: ["عبد الباسط حمودة أنا مش عارفني", "عبد الباسط حمودة ضيعنا", "عبد الباسط حمودة سلفني ضحكتك"], genre: "شعبي ومواويل حزينة", cat: "shaabi", lang: "arabic", bio: "حكمدار الأغنية الشعبية وصاحب أقوى المواويل الشعبية المصرية.", listeners: "2.8M" },
  { name: "Reda El Bahrawy", nameAr: "رضا البحراوي", queries: ["رضا البحراوي إنسان مخيف", "رضا البحراوي سوق الصحاب", "رضا البحراوي سمعت كلامكم"], genre: "شعبي ومواويل حية", cat: "shaabi", lang: "arabic", bio: "نجم الشارع الشعبي وصاحب الحفلات والمواويل الأكثر تداولاً.", listeners: "3.6M" },
  { name: "Tarek El Sheikh", nameAr: "طارق الشيخ", queries: ["طارق الشيخ شارع الحياة", "طارق الشيخ قفلت الباب", "طارق الشيخ راحوا"], genre: "شعبي حزين ودراما", cat: "shaabi", lang: "arabic", bio: "عندليب الأغنية الشعبية الحزينة والمواويل الدرامية المعبرة عن هموم الناس.", listeners: "2.3M" },
  { name: "Hassan El Asmar", nameAr: "حسن الأسمر", queries: ["حسن الأسمر كتاب حياتي يا عين", "حسن الأسمر أنا أهو وانت أهو", "حسن الأسمر سألوني", "حسن الأسمر توهان"], genre: "شعبي ومواويل كلاسيكية", cat: "shaabi", lang: "arabic", bio: "فارس الأغنية والموال الشعبي الحزين صاحب الأغنية الأسطورية «كتاب حياتي يا عين».", listeners: "2.5M" },
  { name: "Mahmoud El Leithy", nameAr: "محمود الليثي", queries: ["محمود الليثي زلزال", "محمود الليثي عم يا صياد", "محمود الليثي بونبوناية"], genre: "شعبي سينمائي وأفراح", cat: "shaabi", lang: "arabic", bio: "نجم الأفراح والأفلام الشعبية المصرية وصاحب الإيقاعات الراقصة.", listeners: "3.9M" },
  { name: "Bossy", nameAr: "بوسي", queries: ["بوسي آه يا دنيا", "بوسي حط إيده يا", "بوسي مش مهم"], genre: "شعبي وبوب استعراضي", cat: "shaabi", lang: "arabic", bio: "نجمة الغناء الشعبي والسينمائي، تميزت بصوتها القوي وأغانيها الضاربة.", listeners: "2.9M" },
  { name: "Mostafa Hajjaj", nameAr: "مصطفى حجاج", queries: ["مصطفى حجاج يا بتاع النعناع", "مصطفى حجاج خطوة", "مصطفى حجاج مننا وعلينا"], genre: "شعبي وبوب مصري", cat: "shaabi", lang: "arabic", bio: "صاحب الصوت الشعبي الرنان وأغاني البهجة كـ «يا بتاع النعناع» و«خطوة».", listeners: "3.9M" },
  { name: "Hassan Shakosh", nameAr: "حسن شاكوش", queries: ["حسن شاكوش بنت الجيران", "حسن شاكوش حبيبتي", "حسن شاكوش عود البطل"], genre: "مهرجانات وترند", cat: "mahraganat", lang: "arabic", bio: "نجم المهرجانات وصاحب أعلى مشاهدات لأغاني الشارع العربي.", listeners: "3.9M" },
  { name: "Omar Kamal", nameAr: "عمر كمال", queries: ["عمر كمال ضيعنا", "عمر كمال أنتي معلمة", "عمر كمال شيكولاتة سايحة"], genre: "مهرجانات وبوب شعبي", cat: "mahraganat", lang: "arabic", bio: "مغني شعبي ومهرجانات حققت أغانيه أرقاماً قياسية في المشاهدات.", listeners: "3.5M" },
  { name: "Essam Sasa", nameAr: "عصام صاصا", queries: ["عصام صاصا الكروان", "عصام صاصا مسا مني ليكو", "عصام صاصا عره فافي"], genre: "مهرجانات شعبية", cat: "mahraganat", lang: "arabic", bio: "أحد أبرز نجوم المهرجانات المعاصرة وأكثرهم استماعاً على المنصات.", listeners: "4.8M" },
  { name: "Muslim", nameAr: "مسلم", queries: ["مسلم اتنسيت", "مسلم قلب في الدفاتر", "مسلم مابقتش أعرفك"], genre: "مهرجانات وبوب بديل", cat: "mahraganat", lang: "arabic", bio: "مغني وملحن مصري اشتهر بأغاني الدراما والمهرجانات ذات الطابع الحزين.", listeners: "3.2M" },
  { name: "3enba", nameAr: "عنبة", queries: ["عنبة طيارة", "عنبة الباشا جالكو", "عنبة كينج اللعبة"], genre: "مهرجانات وتراب شعبي", cat: "mahraganat", lang: "arabic", bio: "نجم التراب والمهرجانات المعاصرة بإيقاعات وطاقة حيوية عالية.", listeners: "2.9M" },
  { name: "Hamo Bika", nameAr: "حمو بيكا", queries: ["حمو بيكا وداع يا دنيا وداع", "حمو بيكا رب الكون ميزنا بميزة"], genre: "مهرجانات وإيقاعات شعبية", cat: "mahraganat", lang: "arabic", bio: "رائد ثورة المهرجانات وصاحب المهرجانات التي انتشرت في كل أرجاء العالم العربي.", listeners: "3.1M" },
  { name: "Ahmed Sheba", nameAr: "أحمد شيبة", queries: ["أحمد شيبة آه لو لعبت يا زهر", "أحمد شيبة يعلم ربنا", "أحمد شيبة من خاف سلم"], genre: "شعبي درامي", cat: "shaabi", lang: "arabic", bio: "صاحب الصوت الشعبي القوي والأغاني الدرامية الشهيرة كـ آه لو لعبت يا زهر.", listeners: "2.4M" },
  { name: "Houda Bondok", nameAr: "حودة بندق", queries: ["حودة بندق بالسلامة", "حودة بندق كله طار في المطار"], genre: "مهرجانات وشعبي حديث", cat: "mahraganat", lang: "arabic", bio: "مغني وملحن شاب برع في تقديم الأغاني الشعبية والمهرجانات بإحساس متجدد.", listeners: "2.7M" },

  // ================= 5. الراب والتراب العربي =================
  { name: "Wegz", nameAr: "ويجز", queries: ["ويجز البخت", "ويجز دورك جاي", "ويجز أميرة", "ويجز كيفي كدا", "ويجز هاسلا"], genre: "راب وتراب مصري", cat: "rap", lang: "arabic", bio: "رائد مشهد التراب والراب المصري الحديث والأكثر تأثيراً في جيل الشباب.", listeners: "6.5M" },
  { name: "Marwan Pablo", nameAr: "مروان بابلو", queries: ["مروان بابلو غابة", "مروان بابلو كنترول", "مروان بابلو فري", "مروان بابلو راكان"], genre: "تراب وراب بديل", cat: "rap", lang: "arabic", bio: "أب التراب المصري وأحد أهم المجددين في الموسيقى المستقلة.", listeners: "2.9M" },
  { name: "Marwan Moussa", nameAr: "مروان موسى", queries: ["مروان موسى بطل العالم", "مروان موسى تيسلا", "مروان موسى شيراتون", "مروان موسى برازيل"], genre: "راب وإنتاج موسيقي", cat: "rap", lang: "arabic", bio: "رابر ومنتج موسيقي مصري فاز بجوائز عالمية بألحانه وتوزيعاته.", listeners: "2.3M" },
  { name: "Afroto", nameAr: "عفروتو", queries: ["عفروتو فرق خبرة", "عفروتو سان ستيفانو", "عفروتو مش بالحظوط", "عفروتو سجارة"], genre: "راب وسين مصري", cat: "rap", lang: "arabic", bio: "رابر مصري يتميز بسرعة الأداء والكلمات المعبرة عن مشهد الشباب.", listeners: "2.5M" },
  { name: "El Joker", nameAr: "الجوكر", queries: ["الجوكر انفصام حاد", "الجوكر رقم 1 ده مش انت", "الجوكر كامل الأوصاف"], genre: "أولد سكول وراب فلسفي", cat: "rap", lang: "arabic", bio: "أحد عمالقة كتابة الراب العربي والمحتوى الفلسفي والدرامي العميق.", listeners: "1.9M" },
  { name: "Abyusif", nameAr: "أبيوسف", queries: ["أبيوسف باشا اعتمد", "أبيوسف ماماز جيرل", "أبيوسف عزرائيل"], genre: "راب بديل وهيب هوب", cat: "rap", lang: "arabic", bio: "الأب الروحي للراب المصري الحديث، أحد أكثر الرابرز غزارة في الإنتاج.", listeners: "1.7M" },

  // ================= 6. نجوم الخليج والعراق واليمن =================
  { name: "Mohammed Abdu", nameAr: "محمد عبده", queries: ["محمد عبده الأماكن", "محمد عبده مذهلة", "محمد عبده صوتك يناديني", "محمد عبده لنا الله"], genre: "طرب خليجي", cat: "khaleeji", lang: "arabic", bio: "فنان العرب، قامة الموسيقى الخليجية والسعودية عبر نصف قرن.", listeners: "3.8M" },
  { name: "Kadim Al Sahir", nameAr: "كاظم الساهر", queries: ["كاظم الساهر أنا وليلى", "كاظم الساهر هل عندك شك", "كاظم الساهر زيديني عشقا", "كاظم الساهر قولي أحبك"], genre: "قصائد وطرب عراقي", cat: "khaleeji", lang: "arabic", bio: "قيصر الغناء العربي وسفير القصيدة النزارية العاطفية.", listeners: "4.1M" },
  { name: "Majed Al Mohandis", nameAr: "ماجد المهندس", queries: ["ماجد المهندس أنا حنيت", "ماجد المهندس هتان", "ماجد المهندس يهز الشوق", "ماجد المهندس عطشان"], genre: "طرب خليجي وعراقي", cat: "khaleeji", lang: "arabic", bio: "برنس الغناء العربي، صاحب الإحساس الراقي والأداء العذب.", listeners: "4.4M" },
  { name: "Rashed Al Majed", nameAr: "راشد الماجد", queries: ["راشد الماجد ولهان", "راشد الماجد يا ناسينا", "راشد الماجد مشكلني", "راشد الماجد السالفة"], genre: "بوب وطرب خليجي", cat: "khaleeji", lang: "arabic", bio: "سندباد الأغنية الخليجية، أحد أعمدة الفن السعودي والعربي.", listeners: "4.6M" },
  { name: "Abdul Majeed Abdullah", nameAr: "عبد المجيد عبد الله", queries: ["عبد المجيد عبد الله غزال ما ينصاد", "عبد المجيد عبد الله حن الغريب", "عبد المجيد عبد الله فزي له يا أرض"], genre: "طرب ورومانسي خليجي", cat: "khaleeji", lang: "arabic", bio: "أمير الطرب الخليجي، فنان الأناقة الصوتية والإحساس الشفيف.", listeners: "5.1M" },
  { name: "Hussain Al Jassmi", nameAr: "حسين الجسمي", queries: ["حسين الجسمي بالبنط العريض", "حسين الجسمي بشرة خير", "حسين الجسمي 6 الصبح", "حسين الجسمي فقدتك"], genre: "بوب وطرب إماراتي وعربي", cat: "khaleeji", lang: "arabic", bio: "سفير الأغنية الإماراتية والعربية وصاحب الأعمال التي تخطت المليارات.", listeners: "6.8M" },
  { name: "Assala", nameAr: "أصالة نصري", queries: ["أصالة شكرا", "أصالة خانات الذكريات", "أصالة بنت أكابر", "أصالة غلبان"], genre: "طربي حديث ورومانسي", cat: "romantic", lang: "arabic", bio: "صاحبة الحنجرة القوية والصوت الشجي في الأغنية العربية والخليجية.", listeners: "5.4M" },
  { name: "Saif Nabeel", nameAr: "سيف نبيل", queries: ["سيف نبيل عشق موت", "سيف نبيل ليلة ورا ليلة", "سيف نبيل دايخ بيك"], genre: "بوب عراقي حديث", cat: "khaleeji", lang: "arabic", bio: "نجم الشباب العراقي وصاحب الهيتات العاطفية واسعة الانتشار.", listeners: "3.7M" },
  { name: "Aseel Hameem", nameAr: "أصيل هميم", queries: ["أصيل هميم سر الحياة", "أصيل هميم المفروض", "أصيل هميم شكد حلو"], genre: "طرب وعاطفي عراقي", cat: "khaleeji", lang: "arabic", bio: "صوت العراق الشجي، تصدرت أغانيها الرومانسية قوائم الاستماع العربية.", listeners: "3.9M" },
  { name: "Mahmoud Al Turky", nameAr: "محمود التركي", queries: ["محمود التركي عاشق مجنون", "محمود التركي تعال", "محمود التركي حاسد روحي"], genre: "بوب عراقي معاصر", cat: "khaleeji", lang: "arabic", bio: "نجم الأغنية العراقية وصاحب الأغاني الأكثر تداولاً وترند.", listeners: "4.3M" },

  // ================= 7. نجوم الشام ولبنان =================
  { name: "Elissa", nameAr: "إليسا", queries: ["إليسا سهرنا يا ليل", "إليسا يا مرايتي", "إليسا كرهني", "إليسا ع بالي حبيبي", "إليسا مكتوبة ليك"], genre: "رومانسي لبناني", cat: "romantic", lang: "arabic", bio: "ملكة الرومانسية اللبنانية، أيقونة الأغاني العاطفية في العالم العربي.", listeners: "5.8M" },
  { name: "Nancy Ajram", nameAr: "نانسي عجرم", queries: ["نانسي عجرم يا طبطب", "نانسي عجرم آه ونص", "نانسي عجرم إحساس جديد", "نانسي عجرم صح صح"], genre: "بوب عربي خفيف", cat: "pop", lang: "arabic", bio: "فراشة البوب اللبناني، من أنجح نجمات الغناء في الوطن العربي.", listeners: "6.9M" },
  { name: "Wael Kfoury", nameAr: "وائل كفوري", queries: ["وائل كفوري البنت القوية", "وائل كفوري كلنا مننجر", "وائل كفوري بيحن", "وائل كفوري بحبك أنا كتير"], genre: "رومانسي لبناني", cat: "romantic", lang: "arabic", bio: "ملك الرومانسية اللبنانية والمواويل الجبلية العاطفية.", listeners: "3.6M" },
  { name: "Ragheb Alama", nameAr: "راغب علامة", queries: ["راغب علامة قلبي عشقها", "راغب علامة سهروني الليل", "راغب علامة اللي باعنا"], genre: "بوب عربي واستعراضي", cat: "pop", lang: "arabic", bio: "السوبر ستار اللبناني، رائد أغاني البوب الراقصة والعاطفية.", listeners: "3.2M" },
  { name: "Fadel Chaker", nameAr: "فضل شاكر", queries: ["فضل شاكر يا غايب", "فضل شاكر لو على قلبي", "فضل شاكر معقول", "فضل شاكر فاكر لما تقولي"], genre: "رومانسي دافئ", cat: "romantic", lang: "arabic", bio: "أمير الرومانسية، تميز بصوته الهادئ وإحساسه الفائق في الغناء.", listeners: "4.8M" },
  { name: "Marwan Khoury", nameAr: "مروان خوري", queries: ["مروان خوري كل القصايد", "مروان خوري قصر الشوق", "مروان خوري أكبر أناني"], genre: "رومانسي وبيانو", cat: "romantic", lang: "arabic", bio: "الشاعر والملحن والمغني الرومانسي، مبدع أروع ألحان الحب العربية.", listeners: "2.7M" },
  { name: "Nassif Zeytoun", nameAr: "ناصيف زيتون", queries: ["ناصيف زيتون بدي ياها", "ناصيف زيتون مش عم تظبط معي", "ناصيف زيتون بربك"], genre: "بوب شامي ورومانسي", cat: "romantic", lang: "arabic", bio: "نجم الأغنية السورية واللبنانية المعاصرة وصاحب الأعمال المليونية.", listeners: "3.5M" },

  // ================= 8. الراي والمغرب العربي =================
  { name: "Saad Lamjarred", nameAr: "سعد لمجرد", queries: ["سعد لمجرد لمعلم", "سعد لمجرد غلطانة", "سعد لمجرد إنت إيه", "سعد لمجرد قولي متى"], genre: "بوب مغربي إلكتروني", cat: "pop", lang: "arabic", bio: "المعلم، صاحب الأغاني المليارية والدمج بين الإيقاع المغربي والعالمي.", listeners: "4.7M" },
  { name: "Cheb Khaled", nameAr: "الشاب خالد", queries: ["الشاب خالد دي دي", "الشاب خالد C'est La Vie", "الشاب خالد عايشة", "الشاب خالد وهران"], genre: "راي وموسيقى عالمية", cat: "world", lang: "arabic", bio: "ملك الراي الجزائري وسفير الموسيقى المغاربية إلى مسارح العالم.", listeners: "3.6M" },
  { name: "Cheb Mami", nameAr: "الشاب مامي", queries: ["الشاب مامي ديزرت روز", "الشاب مامي بلادي", "الشاب مامي لزرق سعيدة"], genre: "راي وبوب جزائري", cat: "world", lang: "arabic", bio: "أمير الراي وصاحب الصوت الأوبرالي الذي وصل لأعظم المسارح العالمية.", listeners: "2.1M" },
  { name: "Saber Rebai", nameAr: "صابر الرباعي", queries: ["صابر الرباعي أتحدى العالم", "صابر الرباعي سيدي منصور", "صابر الرباعي أجمل نساء الدنيا"], genre: "طرب وبوب تونسي", cat: "tarab", lang: "arabic", bio: "أمير الطرب العربي، صاحب الحنجرة الأوبرالية والأداء فائق الجودة.", listeners: "2.2M" },
  { name: "Samira Said", nameAr: "سميرة سعيد", queries: ["سميرة سعيد يوم ورا يوم", "سميرة سعيد هوا هوا", "سميرة سعيد قال جاني بعد يومين"], genre: "ديفا البوب العربي", cat: "pop", lang: "arabic", bio: "الديفا، رائدة التجديد المستمر في الموسيقى العربية عبر عقود.", listeners: "2.6M" },

  // ================= 9. نجوم الموسيقى العالمية =================
  { name: "The Weeknd", nameAr: "ذا ويكند", queries: ["The Weeknd Blinding Lights", "The Weeknd Starboy", "The Weeknd Save Your Tears", "The Weeknd After Hours"], genre: "Synth-Pop & R&B", cat: "pop", lang: "international", bio: "Global megastar behind Blinding Lights, Starboy, and chart-topping synthpop hits.", listeners: "105M" },
  { name: "Coldplay", nameAr: "كولدبلاي", queries: ["Coldplay Viva La Vida", "Coldplay Yellow", "Coldplay A Sky Full of Stars", "Coldplay The Scientist", "Coldplay Fix You"], genre: "Alt-Rock & Pop", cat: "rock", lang: "international", bio: "Legendary British rock band famous for anthems like Viva La Vida & Yellow.", listeners: "85M" },
  { name: "Queen", nameAr: "كوين", queries: ["Queen Bohemian Rhapsody", "Queen Don't Stop Me Now", "Queen We Will Rock You", "Queen Another One Bites the Dust"], genre: "Classic Rock", cat: "rock", lang: "international", bio: "Iconic rock band led by Freddie Mercury with immortal songs like Bohemian Rhapsody.", listeners: "50M" },
  { name: "Eminem", nameAr: "إمينيم", queries: ["Eminem Lose Yourself", "Eminem Without Me", "Eminem Mockingbird", "Eminem Rap God", "Eminem The Real Slim Shady"], genre: "Hip-Hop & Rap", cat: "rap", lang: "international", bio: "Rap God, one of the best-selling music artists and greatest lyricists of all time.", listeners: "70M" },
  { name: "Taylor Swift", nameAr: "تايلور سويفت", queries: ["Taylor Swift Cruel Summer", "Taylor Swift Blank Space", "Taylor Swift Shake It Off", "Taylor Swift Anti-Hero"], genre: "Pop & Singer-Songwriter", cat: "pop", lang: "international", bio: "Global pop phenomenon and record-breaking songwriter.", listeners: "100M" },
  { name: "Adele", nameAr: "أديل", queries: ["Adele Someone Like You", "Adele Rolling in the Deep", "Adele Hello", "Adele Set Fire to the Rain", "Adele Easy On Me"], genre: "Soul & Emotional Pop", cat: "romantic", lang: "international", bio: "British vocal powerhouse behind Someone Like You, Rolling in the Deep, and Hello.", listeners: "55M" },
  { name: "Bruno Mars", nameAr: "برونو مارس", queries: ["Bruno Mars Uptown Funk", "Bruno Mars 24K Magic", "Bruno Mars That's What I Like", "Bruno Mars Just the Way You Are"], genre: "Funk, R&B & Pop", cat: "pop", lang: "international", bio: "Incredible performer and vocalist behind Uptown Funk, 24K Magic, and Leave The Door Open.", listeners: "115M" },
  { name: "Imagine Dragons", nameAr: "إيماجين دراجونس", queries: ["Imagine Dragons Believer", "Imagine Dragons Radioactive", "Imagine Dragons Demons", "Imagine Dragons Bones"], genre: "Electropop & Rock", cat: "rock", lang: "international", bio: "American rock band behind global anthems like Believer, Radioactive, and Bones.", listeners: "62M" },
  { name: "Ludovico Einaudi", nameAr: "لودوفيكو إينودي", queries: ["Ludovico Einaudi Nuvole Bianche", "Ludovico Einaudi Experience", "Ludovico Einaudi Fly", "Ludovico Einaudi Una Mattina"], genre: "Neoclassical & Relaxing Piano", cat: "calm", lang: "international", bio: "Italian composer and pianist known for soothing and evocative instrumental music.", listeners: "12M" }
];

async function runMassIngestion() {
  console.log(`Starting deep multi-query ingestion for ${EXTENSIVE_ARTISTS.length} artist groups...`);

  let addedArtists = 0;
  let addedTracks = 0;

  for (let i = 0; i < EXTENSIVE_ARTISTS.length; i += 4) {
    const chunk = EXTENSIVE_ARTISTS.slice(i, i + 4);
    await Promise.all(
      chunk.map(async (item) => {
        const artistId = `artist_${item.name.toLowerCase().replace(/[^a-z0-9]/g, "_")}`;
        let artistArt = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600";

        for (const queryStr of item.queries) {
          try {
            const url = `https://itunes.apple.com/search?term=${encodeURIComponent(queryStr)}&entity=song&limit=40`;
            const res = await fetch(url, { headers: { "User-Agent": "NaghamMusicApp/1.0" } });
            if (!res.ok) continue;

            const data = await res.json();
            const results = data.results || [];
            if (results.length === 0) continue;

            const first = results[0];
            const artworkHigh = (first.artworkUrl100 || "").replace("100x100bb.jpg", "600x600bb.jpg");
            if (artworkHigh) artistArt = artworkHigh;

            // Insert artist
            await pool.query(
              `INSERT INTO artists (id, name, name_ar, image_url, bio, genre, genre_category, language, monthly_listeners, is_popular)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true)
               ON CONFLICT (id) DO UPDATE SET image_url = EXCLUDED.image_url`,
              [
                artistId,
                item.name,
                item.nameAr || item.name,
                artistArt,
                item.bio,
                item.genre,
                item.cat,
                item.lang,
                item.listeners,
              ]
            );
            addedArtists++;

            // Insert tracks
            for (const track of results) {
              if (!track.previewUrl) continue;
              const trackId = `itunes_${track.trackId}`;
              const trackArtwork = (track.artworkUrl100 || "").replace("100x100bb.jpg", "600x600bb.jpg");
              const fullDur = track.trackTimeMillis ? Math.round(track.trackTimeMillis / 1000) : 240;

              const inserted = await pool.query(
                `INSERT INTO cached_tracks (track_id, title, artist_name, album_name, artwork_url, preview_url, is_full_playable, full_duration_seconds, playback_type, duration_seconds, genre, genre_category, language, release_date)
                 VALUES ($1, $2, $3, $4, $5, $6, true, $7, $8, $9, $10, $11, $12, $13)
                 ON CONFLICT (track_id) DO NOTHING`,
                [
                  trackId,
                  track.trackName || "أغنية",
                  item.nameAr ? `${item.nameAr} (${item.name})` : track.artistName,
                  track.collectionName || "ألبوم",
                  trackArtwork,
                  track.previewUrl,
                  fullDur,
                  "youtube_official",
                  fullDur,
                  track.primaryGenreName || item.genre,
                  item.cat,
                  item.lang,
                  track.releaseDate || "",
                ]
              );
              if (inserted.rowCount > 0) addedTracks++;
            }
          } catch (e) {
            // ignore
          }
        }
      })
    );
    process.stdout.write(`\rProgress: ${Math.min(i + 4, EXTENSIVE_ARTISTS.length)} / ${EXTENSIVE_ARTISTS.length}`);
  }

  const totals = await Promise.all([
    pool.query("SELECT COUNT(*) FROM artists"),
    pool.query("SELECT COUNT(*) FROM cached_tracks"),
    pool.query("SELECT COUNT(*) FROM albums"),
  ]);

  console.log(`\n\nDeep Ingestion Complete!`);
  console.log(`Total Artists in DB: ${totals[0].rows[0].count}`);
  console.log(`Total Songs in DB: ${totals[1].rows[0].count}`);
  console.log(`Total Albums in DB: ${totals[2].rows[0].count}`);
  pool.end();
}

runMassIngestion().catch(console.error);
