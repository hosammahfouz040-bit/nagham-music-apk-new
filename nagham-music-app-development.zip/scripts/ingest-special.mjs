import dotenv from "dotenv";
dotenv.config();
import pg from "pg";
const { Pool } = pg;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const TARGET_ARTISTS = [
  // ================= 1. شفيقة (Shafika) =================
  {
    id: "artist_shafika",
    name: "Shafika",
    nameAr: "شفيقة",
    genre: "شعبي ومواويل كلاسيكية",
    cat: "shaabi",
    lang: "arabic",
    bio: "سلطانة الموال والأغنية الشعبية المصرية، صاحبة الصوت الشجي وأشهر مواويل الشارع كـ «بتحب مين يا قلبي» و«عينيا حزينة».",
    listeners: "2.1M",
    queries: [
      "شفيقة",
      "شفيقة بتحب مين يا قلبي",
      "شفيقة عينيا حزينة",
      "شفيقة رايح فين",
      "شفيقة أنا وأنت",
      "شفيقة لو غبت عني",
      "شفيقة الصبر طيب",
      "شفيقة تفرق كتير",
      "شفيقة مواويل",
      "شفيقة يا قلبي ارتاح",
      "شفيقة مسا الجمال",
      "شفيقة شعبي مصري",
      "Shafika Shaabi",
      "Shafika Egyptian",
    ],
  },

  // ================= 2. محمد منير (Mohamed Mounir) =================
  {
    id: "artist_mohamed_mounir",
    name: "Mohamed Mounir",
    nameAr: "محمد منير",
    genre: "موسيقى نوبية وبوب بديل",
    cat: "world",
    lang: "arabic",
    bio: "الكينج محمد منير، صاحب الصوت الفريد والدمج بين التراث النوبي والمصري والموسيقى العالمية.",
    listeners: "5.8M",
    queries: [
      "محمد منير الليلة يا سمرا",
      "محمد منير علي صوتك",
      "محمد منير شبابيك",
      "محمد منير يونس",
      "محمد منير سو يا سو",
      "محمد منير حدوتة مصرية",
      "محمد منير في عشق البنات",
      "محمد منير علموني عينيكي",
      "محمد منير الكون كله بيدور",
      "محمد منير طعم البيوت",
      "محمد منير أنا قلبي مساكن شعبية",
      "محمد منير يا طير يا طاير",
      "محمد منير شجر الليمون",
      "محمد منير أهل العرب والطرب",
      "محمد منير ممكن",
      "محمد منير وسط الدايرة",
      "محمد منير امبارح كان عمري عشرين",
      "محمد منير بريء",
      "محمد منير افتح قلبك",
      "محمد منير الدنيا ريشة في هوا",
      "محمد منير إمبارح",
      "محمد منير قلبي مساكن شعبية",
      "محمد منير لما النسيم",
      "محمد منير حارة السقايين",
      "محمد منير يا حمام",
      "محمد منير ربك لما يريد",
      "Mohamed Mounir",
      "Mohamed Mounir Album",
      "Mounir The King",
    ],
  },

  // ================= 3. عبد الحليم حافظ (Abdel Halim Hafez) =================
  {
    id: "artist_abdel_halim_hafez",
    name: "Abdel Halim Hafez",
    nameAr: "عبد الحليم حافظ",
    genre: "طرب ورومانسي",
    cat: "tarab",
    lang: "arabic",
    bio: "العندليب الأسمر، صاحب الصوت الشجي وأعظم أغاني الحب والسينما المصرية الخالدة.",
    listeners: "4.8M",
    queries: [
      "عبد الحليم حافظ قارئة الفنجان",
      "عبد الحليم حافظ سواح",
      "عبد الحليم حافظ جانا الهوى",
      "عبد الحليم حافظ زي الهوا",
      "عبد الحليم حافظ أهواك",
      "عبد الحليم حافظ موعود",
      "عبد الحليم حافظ على حسب وداد",
      "عبد الحليم حافظ توبة",
      "عبد الحليم حافظ أي دمعة حزن لا",
      "عبد الحليم حافظ حبيبتي من تكون",
      "عبد الحليم حافظ حاول تفتكرني",
      "عبد الحليم حافظ فاتت جنبنا",
      "عبد الحليم حافظ رسالة من تحت الماء",
      "عبد الحليم حافظ نبتدي منين الحكاية",
      "عبد الحليم حافظ بحلم بيك",
      "عبد الحليم حافظ في يوم في شهر في سنة",
      "عبد الحليم حافظ أول مرة تحب يا قلبي",
      "عبد الحليم حافظ يا خلي القلب",
      "عبد الحليم حافظ بتلوموني ليه",
      "عبد الحليم حافظ خسارة",
      "عبد الحليم حافظ ضحك ولعب وجد وحب",
      "عبد الحليم حافظ جبار",
      "عبد الحليم حافظ صافيني مرة",
      "عبد الحليم حافظ يا سيدي أمرك",
      "عبد الحليم حافظ حاجة غريبة",
      "عبد الحليم حافظ قولوله الحقيقة",
      "عبد الحليم حافظ بلاش عتاب",
      "عبد الحليم حافظ كامل الأوصاف",
      "عبد الحليم حافظ حبيبها",
      "عبد الحليم حافظ مغرور",
      "عبد الحليم حافظ يا قلبي خبي",
      "Abdel Halim Hafez",
      "Abdel Halim Hafez Live",
      "Abdel Halim Hafez Hits",
    ],
  },
];

async function ingestTargetArtists() {
  console.log("Starting targeted deep ingestion for Shafika, Mohamed Mounir, and Abdel Halim Hafez...");

  for (const item of TARGET_ARTISTS) {
    console.log(`\nProcessing ${item.nameAr} (${item.name}) across ${item.queries.length} query variations...`);

    let artistTracks = 0;
    let artistArt = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600";

    for (const queryStr of item.queries) {
      try {
        const url = `https://itunes.apple.com/search?term=${encodeURIComponent(queryStr)}&entity=song&limit=40`;
        const res = await fetch(url, { headers: { "User-Agent": "NaghamMusicApp/1.0" } });
        if (!res.ok) continue;

        const data = await res.json();
        const results = data.results || [];
        if (results.length === 0) continue;

        const first = results[0];
        const artworkHigh = (first.artworkUrl100 || "").replace("100x100bb.jpg", "600x600bb.jpg");
        if (artworkHigh && !artistArt.includes("mzstatic")) {
          artistArt = artworkHigh;
        }

        // Insert or update artist
        await pool.query(
          `INSERT INTO artists (id, name, name_ar, image_url, bio, genre, genre_category, language, monthly_listeners, is_popular)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true)
           ON CONFLICT (id) DO UPDATE SET image_url = EXCLUDED.image_url, bio = EXCLUDED.bio, monthly_listeners = EXCLUDED.monthly_listeners`,
          [
            item.id,
            item.name,
            item.nameAr,
            artistArt,
            item.bio,
            item.genre,
            item.cat,
            item.lang,
            item.listeners,
          ]
        );

        // Insert primary album
        const albumId = `album_${(first.collectionName || item.name).toLowerCase().replace(/[^a-z0-9]/g, "_")}`;
        await pool.query(
          `INSERT INTO albums (id, title, artist_name, artist_id, cover_url, release_year, genre, genre_category, language, total_tracks)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
           ON CONFLICT (id) DO NOTHING`,
          [
            albumId,
            first.collectionName || `أفضل أغاني ${item.nameAr}`,
            item.nameAr,
            item.id,
            artistArt,
            first.releaseDate ? new Date(first.releaseDate).getFullYear().toString() : "2024",
            item.genre,
            item.cat,
            item.lang,
            results.length,
          ]
        );

        // Insert tracks
        for (const track of results) {
          if (!track.previewUrl) continue;
          const trackId = `itunes_${track.trackId}`;
          const trackArtwork = (track.artworkUrl100 || "").replace("100x100bb.jpg", "600x600bb.jpg");
          const fullDur = track.trackTimeMillis ? Math.round(track.trackTimeMillis / 1000) : 240;

          const inserted = await pool.query(
            `INSERT INTO cached_tracks (track_id, title, artist_name, album_name, artwork_url, preview_url, is_full_playable, full_duration_seconds, playback_type, duration_seconds, genre, genre_category, language, release_date)
             VALUES ($1, $2, $3, $4, $5, $6, true, $7, $8, $9, $10, $11, $12, $13)
             ON CONFLICT (track_id) DO UPDATE SET is_full_playable = true, full_duration_seconds = EXCLUDED.full_duration_seconds`,
            [
              trackId,
              track.trackName || "أغنية",
              `${item.nameAr} (${item.name})`,
              track.collectionName || "ألبوم",
              trackArtwork,
              track.previewUrl,
              fullDur,
              "youtube_official",
              fullDur,
              track.primaryGenreName || item.genre,
              item.cat,
              item.lang,
              track.releaseDate || "",
            ]
          );
          if (inserted.rowCount > 0) artistTracks++;
        }
      } catch (e) {
        // ignore
      }
    }

    const countRes = await pool.query("SELECT COUNT(*) FROM cached_tracks WHERE artist_name ILIKE $1", [`%${item.nameAr}%`]);
    console.log(`✓ Completed ${item.nameAr}: ${countRes.rows[0].count} total songs indexed in database!`);
  }

  const totals = await Promise.all([
    pool.query("SELECT COUNT(*) FROM artists"),
    pool.query("SELECT COUNT(*) FROM cached_tracks"),
    pool.query("SELECT COUNT(*) FROM albums"),
  ]);

  console.log("\n=== UPDATED SYSTEM METRICS ===");
  console.log("Total Artists in DB:", totals[0].rows[0].count);
  console.log("Total Songs in DB:", totals[1].rows[0].count);
  console.log("Total Albums in DB:", totals[2].rows[0].count);

  pool.end();
}

ingestTargetArtists().catch(console.error);
