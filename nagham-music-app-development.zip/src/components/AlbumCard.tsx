"use client";

import React from "react";
import Link from "next/link";
import { Album } from "@/lib/types";
import { Disc3, Calendar, Sparkles } from "lucide-react";

interface AlbumCardProps {
  album: Album;
}

export function AlbumCard({ album }: AlbumCardProps) {
  return (
    <Link
      href={`/albums/${encodeURIComponent(album.id)}`}
      className="group relative flex flex-col p-3 sm:p-3.5 rounded-3xl bg-[#121218]/70 hover:bg-[#1a1a24] border border-white/[0.06] hover:border-emerald-500/40 transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-emerald-950/20"
    >
      {/* Square Cover Art with Luxury Shadow */}
      <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-zinc-900 mb-3 shadow-lg border border-white/[0.08] group-hover:border-emerald-500/30 transition-colors duration-300">
        {album.coverUrl ? (
          <img
            src={album.coverUrl}
            alt={album.title}
            className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 ease-out"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Disc3 className="w-12 h-12 text-zinc-600" />
          </div>
        )}

        {/* Year tag badge */}
        <div className="absolute top-2.5 right-2.5 bg-zinc-950/85 backdrop-blur-md px-2.5 py-0.5 rounded-lg text-[10px] font-bold text-zinc-200 border border-white/[0.1] flex items-center gap-1 shadow-md">
          <Calendar className="w-3 h-3 text-emerald-400" />
          {album.releaseYear}
        </div>

        {/* Subtle dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Details */}
      <div className="text-right px-1">
        <h4 className="text-sm sm:text-base font-bold text-zinc-100 group-hover:text-emerald-300 transition-colors duration-200 truncate">
          {album.title}
        </h4>
        <p className="text-xs text-zinc-400 truncate mt-0.5">{album.artistName}</p>
        <div className="flex items-center justify-between text-[10px] text-zinc-400 mt-2 font-medium">
          <span className="bg-white/[0.04] px-2 py-0.5 rounded-md border border-white/[0.04]">{album.genre}</span>
          <span className="text-emerald-400/90 font-bold">{album.totalTracks} مقطع كامل</span>
        </div>
      </div>
    </Link>
  );
}
