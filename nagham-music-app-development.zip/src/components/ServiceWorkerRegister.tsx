"use client";

import React, { useEffect, useState } from "react";
import { WifiOff, Wifi, Download, CheckCircle2, X, Smartphone, Sparkles, ArrowDownToLine } from "lucide-react";

export function ServiceWorkerRegister() {
  const [isOffline, setIsOffline] = useState(false);
  const [showOfflineToast, setShowOfflineToast] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBanner, setShowInstallBanner] = useState(false);

  useEffect(() => {
    // 1. Register Service Worker for offline capabilities
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/sw.js")
        .then((reg) => {
          console.log("[Nagham SW] Service Worker successfully registered with scope:", reg.scope);
        })
        .catch((err) => {
          console.warn("[Nagham SW] Registration failed:", err);
        });
    }

    // 2. Online / Offline status monitoring
    const handleOnline = () => {
      setIsOffline(false);
      setShowOfflineToast(true);
      setTimeout(() => setShowOfflineToast(false), 3000);
    };

    const handleOffline = () => {
      setIsOffline(true);
      setShowOfflineToast(true);
    };

    if (typeof window !== "undefined") {
      setIsOffline(!navigator.onLine);
      window.addEventListener("online", handleOnline);
      window.addEventListener("offline", handleOffline);

      // 3. Capture PWA beforeinstallprompt
      window.addEventListener("beforeinstallprompt", (e: any) => {
        e.preventDefault();
        setDeferredPrompt(e);
        // Show install promo if not already installed
        const isStandalone = window.matchMedia("(display-mode: standalone)").matches;
        if (!isStandalone) {
          setShowInstallBanner(true);
        }
      });
    }

    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("online", handleOnline);
        window.removeEventListener("offline", handleOffline);
      }
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        console.log("User accepted the Nagham install prompt");
      }
      setDeferredPrompt(null);
      setShowInstallBanner(false);
    } else {
      window.location.href = "/download";
    }
  };

  return (
    <>
      {/* Offline Status Alert Toast */}
      {showOfflineToast && (
        <div
          className={`fixed top-18 sm:top-20 right-4 left-4 sm:left-auto sm:max-w-md z-50 p-3.5 rounded-2xl backdrop-blur-xl border shadow-2xl transition-all duration-300 animate-in slide-in-from-top-4 flex items-center justify-between gap-3 ${
            isOffline
              ? "bg-amber-950/90 border-amber-500/40 text-amber-200"
              : "bg-emerald-950/90 border-emerald-500/40 text-emerald-200"
          }`}
        >
          <div className="flex items-center gap-2.5">
            {isOffline ? (
              <WifiOff className="w-5 h-5 text-amber-400 shrink-0 animate-pulse" />
            ) : (
              <Wifi className="w-5 h-5 text-emerald-400 shrink-0" />
            )}
            <div className="text-right">
              <p className="text-xs font-bold">
                {isOffline ? "أنت في وضع عدم الاتصال (Offline Mode)" : "تمت استعادة الاتصال بالإنترنت"}
              </p>
              <p className="text-[10px] text-zinc-300">
                {isOffline
                  ? "تطبيق نغم يعمل بدون إنترنت! يمكنك الاستماع إلى أغانيك المحفوظة ومكتبتك."
                  : "تمت مزامنة الأغاني والمطربين بنجاح."}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowOfflineToast(false)}
            className="p-1 rounded-lg text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Floating Offline Indicator Badge if offline */}
      {isOffline && !showOfflineToast && (
        <div className="fixed top-20 right-4 z-40 bg-amber-950/90 border border-amber-500/40 text-amber-300 px-3 py-1 rounded-full text-[10px] font-bold shadow-lg flex items-center gap-1.5 backdrop-blur-md">
          <WifiOff className="w-3 h-3 text-amber-400" />
          <span>وضع عدم الاتصال (بدون إنترنت)</span>
        </div>
      )}

      {/* Floating Quick Install Banner on Android */}
      {showInstallBanner && (
        <div className="fixed bottom-28 md:bottom-20 right-3 left-3 sm:left-auto sm:right-6 sm:max-w-md z-40 p-4 rounded-3xl bg-[#12121c]/95 backdrop-blur-2xl border border-emerald-500/40 shadow-2xl animate-in slide-in-from-bottom-5 flex items-center justify-between gap-3 text-right">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-zinc-950 shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-black text-white">تثبيت تطبيق نغم على هاتفك</p>
              <p className="text-[10px] text-zinc-300">يعمل بدون إنترنت وبشاشة كاملة</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleInstallClick}
              className="px-3.5 py-2 bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-black text-xs rounded-xl shadow-md hover:scale-105 active:scale-95 transition"
            >
              تثبيت الآن
            </button>
            <button
              onClick={() => setShowInstallBanner(false)}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg"
              title="إغلاق"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
