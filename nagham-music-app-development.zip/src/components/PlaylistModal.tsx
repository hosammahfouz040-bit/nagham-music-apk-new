"use client";

import React, { useState, useEffect } from "react";
import { Track, Playlist } from "@/lib/types";
import { X, Plus, Check, ListMusic, Music } from "lucide-react";

interface PlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTrack?: Track | null;
  onPlaylistCreated?: () => void;
}

export function PlaylistModal({
  isOpen,
  onClose,
  selectedTrack,
  onPlaylistCreated,
}: PlaylistModalProps) {
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [newPlaylistDesc, setNewPlaylistDesc] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchPlaylists();
      setMessage(null);
    }
  }, [isOpen]);

  const fetchPlaylists = async () => {
    try {
      const res = await fetch("/api/playlists");
      const data = await res.json();
      if (data.success) {
        setPlaylists(data.data || []);
      }
    } catch (err) {
      console.error("Error loading playlists:", err);
    }
  };

  const handleCreatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;

    setLoading(true);
    try {
      const res = await fetch("/api/playlists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newPlaylistName.trim(),
          description: newPlaylistDesc.trim(),
          coverUrl: selectedTrack?.artworkUrl || "",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setNewPlaylistName("");
        setNewPlaylistDesc("");
        setIsCreating(false);
        fetchPlaylists();
        if (onPlaylistCreated) onPlaylistCreated();
        setMessage("تم إنشاء قائمة التشغيل بنجاح!");
      }
    } catch {
      setMessage("حدث خطأ أثناء الإنشاء");
    } finally {
      setLoading(false);
    }
  };

  const handleAddToPlaylist = async (playlistId: string) => {
    if (!selectedTrack) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/playlists/${playlistId}/items`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          trackId: selectedTrack.trackId,
          title: selectedTrack.title,
          artistName: selectedTrack.artistName,
          albumName: selectedTrack.albumName,
          artworkUrl: selectedTrack.artworkUrl,
          previewUrl: selectedTrack.previewUrl,
          durationSeconds: selectedTrack.durationSeconds,
        }),
      });
      const data = await res.json();
      setMessage(data.message || "تمت إضافة الأغنية!");
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch {
      setMessage("تعذر الإضافة للقائمة");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-md p-5 text-right shadow-2xl relative">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <button onClick={onClose} className="p-1 rounded-lg text-zinc-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <ListMusic className="w-5 h-5 text-emerald-400" />
            <span>{selectedTrack ? "إضافة لقائمة تشغيل" : "قوائم التشغيل"}</span>
          </h3>
        </div>

        {/* Selected Track Banner if adding */}
        {selectedTrack && (
          <div className="flex items-center gap-3 p-2.5 my-3 rounded-xl bg-zinc-800/60 border border-zinc-700/50">
            <img src={selectedTrack.artworkUrl} alt={selectedTrack.title} className="w-10 h-10 rounded-lg object-cover" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-white truncate">{selectedTrack.title}</p>
              <p className="text-[11px] text-zinc-400 truncate">{selectedTrack.artistName}</p>
            </div>
          </div>
        )}

        {message && (
          <div className="p-2.5 my-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs text-center font-medium">
            {message}
          </div>
        )}

        {/* Create Form Toggle */}
        {!isCreating ? (
          <button
            onClick={() => setIsCreating(true)}
            className="w-full py-2.5 px-4 mb-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>إنشاء قائمة تشغيل جديدة</span>
          </button>
        ) : (
          <form onSubmit={handleCreatePlaylist} className="flex flex-col gap-2.5 my-3 p-3 bg-zinc-800/40 rounded-xl border border-zinc-700/60">
            <input
              type="text"
              placeholder="اسم قائمة التشغيل (مثال: أغاني السفر، سهرة طرب)"
              value={newPlaylistName}
              onChange={(e) => setNewPlaylistName(e.target.value)}
              className="w-full bg-zinc-800 text-xs text-white p-2.5 rounded-lg border border-zinc-700 focus:border-emerald-500 outline-none"
              required
            />
            <input
              type="text"
              placeholder="وصف اختياري..."
              value={newPlaylistDesc}
              onChange={(e) => setNewPlaylistDesc(e.target.value)}
              className="w-full bg-zinc-800 text-xs text-white p-2.5 rounded-lg border border-zinc-700 focus:border-emerald-500 outline-none"
            />
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-2 bg-emerald-500 text-zinc-950 font-bold text-xs rounded-lg hover:bg-emerald-400 transition"
              >
                {loading ? "جاري الحفظ..." : "حفظ القائمة"}
              </button>
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-3 py-2 bg-zinc-800 text-zinc-300 text-xs rounded-lg hover:bg-zinc-700 transition"
              >
                إلغاء
              </button>
            </div>
          </form>
        )}

        {/* Existing Playlists list */}
        <div className="flex flex-col gap-1.5 max-h-48 overflow-y-auto">
          {playlists.length === 0 ? (
            <p className="text-center text-xs text-zinc-500 py-4">لا توجد قوائم تشغيل حتى الآن</p>
          ) : (
            playlists.map((pl) => (
              <div
                key={pl.id}
                onClick={() => selectedTrack && handleAddToPlaylist(pl.id)}
                className="flex items-center justify-between p-2 rounded-xl hover:bg-zinc-800 cursor-pointer border border-transparent hover:border-zinc-700 transition"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-zinc-800 flex items-center justify-center">
                    <Music className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-semibold text-white">{pl.name}</p>
                    <p className="text-[10px] text-zinc-400">{pl.isSystem ? "رسمية" : "مخصصة"}</p>
                  </div>
                </div>
                {selectedTrack && (
                  <button className="text-xs text-emerald-400 p-1 hover:underline">إضافة</button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
