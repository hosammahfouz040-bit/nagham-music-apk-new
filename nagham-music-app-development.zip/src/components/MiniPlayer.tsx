"use client";

import React from "react";
import { usePlayer } from "@/context/PlayerContext";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Heart,
  Maximize2,
  ListMusic,
  Repeat,
  Shuffle,
  Music,
  Sparkles,
  CheckCircle2,
  Radio,
} from "lucide-react";
import { AudioVisualizer } from "./AudioVisualizer";

export function MiniPlayer() {
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    togglePlay,
    nextTrack,
    prevTrack,
    seek,
    setVolumeLevel,
    toggleMute,
    toggleShuffle,
    toggleRepeat,
    toggleFavorite,
    isFavorite,
    openFullPlayer,
    openSourceModal,
    queue,
  } = usePlayer();

  if (!currentTrack) return null;

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isFav = isFavorite(currentTrack.trackId);

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  return (
    <div className="fixed bottom-14 md:bottom-0 left-0 right-0 z-35 bg-[#060608]/92 backdrop-blur-2xl border-t border-white/[0.08] shadow-2xl shadow-black transition-all duration-300">
      {/* Top progress seek bar on mobile & desktop with glow */}
      <div
        className="w-full h-1.5 bg-zinc-900/80 relative cursor-pointer group"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          const ratio = Math.max(0, Math.min(1, clickX / rect.width));
          seek(ratio * duration);
        }}
      >
        <div
          className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 transition-all duration-100 relative group-hover:h-2"
          style={{ width: `${progressPercent}%` }}
        >
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-white rounded-full shadow-lg shadow-emerald-500/50 opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2 sm:gap-4">
        {/* Track Info (Right in RTL) */}
        <div className="flex items-center gap-3 min-w-0 max-w-[45%] sm:max-w-[34%]">
          <div
            onClick={openFullPlayer}
            className="relative w-12 h-12 sm:w-13 sm:h-13 rounded-2xl overflow-hidden shrink-0 cursor-pointer shadow-lg border border-white/[0.1] group"
          >
            {currentTrack.artworkUrl ? (
              <img
                src={currentTrack.artworkUrl}
                alt={currentTrack.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full bg-zinc-900 flex items-center justify-center">
                <Music className="w-5 h-5 text-zinc-500" />
              </div>
            )}
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
              <Maximize2 className="w-4 h-4 text-white" />
            </div>
          </div>

          <div className="min-w-0 flex flex-col justify-center cursor-pointer text-right" onClick={openFullPlayer}>
            <div className="flex items-center gap-1.5">
              <span className="text-xs sm:text-sm font-bold text-white truncate hover:text-emerald-300 transition-colors">
                {currentTrack.title}
              </span>
              <AudioVisualizer isPlaying={isPlaying} barCount={3} className="hidden sm:flex shrink-0" />
            </div>
            <span className="text-[11px] text-zinc-400 truncate mt-0.5">{currentTrack.artistName}</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="text-[9px] text-emerald-300 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-md font-bold flex items-center gap-1 shadow-sm">
                <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                أغنية كاملة (Full Track)
              </span>
            </div>
          </div>

          {/* Favorite button */}
          <button
            onClick={() => toggleFavorite(currentTrack)}
            className="p-1.5 text-zinc-400 hover:text-rose-500 transition-colors rounded-full shrink-0"
            title={isFav ? "إزالة من المفضلة" : "إضافة للمفضلة"}
          >
            <Heart className={`w-4 h-4 sm:w-5 sm:h-5 ${isFav ? "fill-rose-500 text-rose-500" : ""}`} />
          </button>
        </div>

        {/* Center Main Controls */}
        <div className="flex flex-col items-center gap-1 flex-1 max-w-md">
          <div className="flex items-center gap-2.5 sm:gap-4">
            {/* Shuffle (desktop) */}
            <button
              onClick={toggleShuffle}
              className={`p-2 rounded-xl transition-all duration-200 hidden sm:block ${
                isShuffle ? "text-emerald-400 bg-emerald-500/15" : "text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04]"
              }`}
              title="تشغيل عشوائي"
            >
              <Shuffle className="w-4 h-4" />
            </button>

            {/* Previous */}
            <button
              onClick={prevTrack}
              className="p-2 text-zinc-300 hover:text-white transition-all rounded-xl hover:bg-white/[0.06]"
              title="السابق"
            >
              <SkipBack className="w-5 h-5 rtl:rotate-180" />
            </button>

            {/* Play/Pause Luxury Button */}
            <button
              onClick={togglePlay}
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 hover:from-emerald-400 hover:to-cyan-300 text-zinc-950 flex items-center justify-center shadow-lg shadow-emerald-500/30 transition-all duration-200 active:scale-95"
              title={isPlaying ? "إيقاف مؤقت" : "تشغيل"}
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-zinc-950" /> : <Play className="w-5 h-5 fill-zinc-950 ml-0.5" />}
            </button>

            {/* Next */}
            <button
              onClick={nextTrack}
              className="p-2 text-zinc-300 hover:text-white transition-all rounded-xl hover:bg-white/[0.06]"
              title="التالي"
            >
              <SkipForward className="w-5 h-5 rtl:rotate-180" />
            </button>

            {/* Repeat (desktop) */}
            <button
              onClick={toggleRepeat}
              className={`p-2 rounded-xl transition-all duration-200 hidden sm:block relative ${
                repeatMode !== "off" ? "text-emerald-400 bg-emerald-500/15" : "text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04]"
              }`}
              title={`وضع التكرار: ${repeatMode}`}
            >
              <Repeat className="w-4 h-4" />
              {repeatMode === "one" && (
                <span className="absolute -top-1 -right-1 text-[9px] font-bold bg-emerald-500 text-zinc-950 rounded-full w-3.5 h-3.5 flex items-center justify-center">
                  1
                </span>
              )}
            </button>
          </div>

          {/* Time tracker (desktop) */}
          <div className="hidden sm:flex items-center gap-2 text-[11px] text-zinc-400 w-full justify-center font-medium">
            <span>{formatTime(currentTime)}</span>
            <div className="w-48 h-1 bg-zinc-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Left Controls: Volume & Expand */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Options / External Source button */}
          <button
            onClick={() => openSourceModal(currentTrack)}
            className="p-2 text-zinc-400 hover:text-emerald-400 rounded-xl hover:bg-white/[0.06] transition"
            title="خيارات ومصادر الاستماع"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Volume Control */}
          <div className="relative hidden md:flex items-center gap-1.5">
            <button
              onClick={toggleMute}
              className="p-2 text-zinc-400 hover:text-zinc-200 transition-colors rounded-xl hover:bg-white/[0.06]"
              title={isMuted ? "إلغاء الكتم" : "كتم الصوت"}
            >
              {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.02"
              value={isMuted ? 0 : volume}
              onChange={(e) => setVolumeLevel(parseFloat(e.target.value))}
              className="w-16 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
          </div>

          {/* Queue Count */}
          <button
            onClick={openFullPlayer}
            className="flex items-center gap-1 p-2 text-zinc-400 hover:text-zinc-200 rounded-xl hover:bg-white/[0.06] transition"
            title="قائمة التشغيل"
          >
            <ListMusic className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="text-[11px] font-bold text-zinc-400 hidden sm:inline">{queue.length}</span>
          </button>

          {/* Full Player expander */}
          <button
            onClick={openFullPlayer}
            className="p-2 text-zinc-400 hover:text-white rounded-xl hover:bg-white/[0.06] transition"
            title="تكبير المشغل"
          >
            <Maximize2 className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
