"use client";

import React from "react";
import { usePlayer } from "@/context/PlayerContext";
import { ExternalSourceModal } from "./ExternalSourceModal";

export function SourceModalContainer() {
  const { isSourceModalOpen, closeSourceModal, sourceModalTrack } = usePlayer();

  return (
    <ExternalSourceModal
      isOpen={isSourceModalOpen}
      onClose={closeSourceModal}
      track={sourceModalTrack}
    />
  );
}
