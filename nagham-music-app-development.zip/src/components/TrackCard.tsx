"use client";

import React, { useState } from "react";
import { Track } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import {
  Play,
  Pause,
  Heart,
  MoreVertical,
  Plus,
  Music,
  Share2,
  Check,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import { AudioVisualizer } from "./AudioVisualizer";

interface TrackCardProps {
  track: Track;
  trackList?: Track[];
  viewMode?: "grid" | "list";
  index?: number;
  onAddToPlaylist?: (track: Track) => void;
}

export function TrackCard({
  track,
  trackList,
  viewMode = "grid",
  index,
  onAddToPlaylist,
}: TrackCardProps) {
  const {
    currentTrack,
    isPlaying,
    playTrack,
    togglePlay,
    toggleFavorite,
    isFavorite,
    addToQueue,
    openSourceModal,
  } = usePlayer();

  const [showMenu, setShowMenu] = useState(false);
  const [copied, setCopied] = useState(false);

  const isCurrent = currentTrack?.trackId === track.trackId;
  const isFav = isFavorite(track.trackId);

  const formatDuration = (sec?: number | null) => {
    if (!sec || isNaN(sec)) return "";
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? "0" : ""}${s}`;
  };

  const handlePlayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCurrent) {
      togglePlay();
    } else {
      playTrack(track, trackList || [track], "full");
    }
  };

  const handleFavClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(track);
  };

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(track.externalAppleMusicUrl || track.externalYoutubeUrl || window.location.href);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
      setShowMenu(false);
    }, 1500);
  };

  // GRID VIEW (Luxury card for rows & carousels)
  if (viewMode === "grid") {
    return (
      <div
        onClick={handlePlayClick}
        className={`group relative rounded-3xl p-3 sm:p-3.5 transition-all duration-300 flex flex-col justify-between cursor-pointer border ${
          isCurrent
            ? "bg-[#181826] border-emerald-500/50 shadow-xl shadow-emerald-950/30 scale-[1.02]"
            : "bg-[#121218]/70 hover:bg-[#1a1a24] border-white/[0.06] hover:border-emerald-500/35 hover:scale-[1.03] hover:shadow-2xl hover:shadow-black/70"
        }`}
      >
        {/* Cover Image & Hover Play Button */}
        <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-zinc-900 mb-3 shadow-md border border-white/[0.08]">
          {track.artworkUrl ? (
            <img
              src={track.artworkUrl}
              alt={track.title}
              className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-700 ease-out"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Music className="w-8 h-8 text-zinc-600" />
            </div>
          )}

          {/* Badge: Full Track duration */}
          <div className="absolute top-2.5 right-2.5 z-10">
            <span className="text-[10px] font-bold bg-zinc-950/85 backdrop-blur-md text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-lg flex items-center gap-1 shadow-md">
              <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
              كاملة {track.fullDurationSeconds ? `(${formatDuration(track.fullDurationSeconds)})` : ""}
            </span>
          </div>

          {/* Center Play Button Overlay */}
          <div
            className={`absolute inset-0 bg-black/45 backdrop-blur-[2px] flex items-center justify-center transition-all duration-300 ${
              isCurrent ? "opacity-100" : "opacity-0 group-hover:opacity-100"
            }`}
          >
            <button
              onClick={handlePlayClick}
              className="w-12 h-12 sm:w-13 sm:h-13 rounded-2xl text-zinc-950 flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all duration-200 bg-gradient-to-tr from-emerald-500 via-teal-400 to-cyan-400 shadow-emerald-500/50"
              title={isCurrent && isPlaying ? "إيقاف مؤقت" : "تشغيل الأغنية كاملة"}
            >
              {isCurrent && isPlaying ? (
                <Pause className="w-6 h-6 fill-zinc-950" />
              ) : (
                <Play className="w-6 h-6 fill-zinc-950 ml-0.5" />
              )}
            </button>
          </div>

          {/* Equalizer Indicator when playing */}
          {isCurrent && isPlaying && (
            <div className="absolute bottom-2 left-2 bg-zinc-950/90 backdrop-blur-md px-2 py-1 rounded-lg border border-emerald-500/30 shadow-lg">
              <AudioVisualizer isPlaying={isPlaying} barCount={4} />
            </div>
          )}
        </div>

        {/* Text Info & Favorite Button */}
        <div className="flex items-start justify-between gap-2 px-1">
          <div className="min-w-0 flex-1 text-right">
            <h4
              className={`text-xs sm:text-sm font-bold truncate transition-colors duration-200 ${
                isCurrent ? "text-emerald-300" : "text-white group-hover:text-emerald-300"
              }`}
            >
              {track.title}
            </h4>
            <p className="text-[11px] text-zinc-400 truncate mt-0.5 font-medium">{track.artistName}</p>
          </div>

          <button
            onClick={handleFavClick}
            className="p-1.5 text-zinc-400 hover:text-rose-500 rounded-full transition-colors shrink-0"
            title={isFav ? "إزالة من المفضلة" : "إضافة للمفضلة"}
          >
            <Heart className={`w-4 h-4 ${isFav ? "fill-rose-500 text-rose-500" : ""}`} />
          </button>
        </div>
      </div>
    );
  }

  // LIST VIEW (Refined list row for tracklists & search)
  return (
    <div
      onClick={handlePlayClick}
      className={`group flex items-center justify-between p-3 sm:p-3.5 rounded-2xl border transition-all duration-200 cursor-pointer ${
        isCurrent
          ? "bg-gradient-to-r from-emerald-950/30 via-[#181826] to-[#14141e] border-emerald-500/40 text-emerald-200 shadow-lg shadow-emerald-950/20"
          : "bg-[#121218]/60 hover:bg-[#181822] border-white/[0.06] hover:border-white/[0.12]"
      }`}
    >
      {/* Left: Index / Play Icon & Track Artwork & Title */}
      <div className="flex items-center gap-3 min-w-0 flex-1">
        {/* Index number or Visualizer */}
        <div className="w-6 text-center text-xs text-zinc-500 group-hover:text-emerald-400 shrink-0 font-bold hidden sm:block">
          {isCurrent && isPlaying ? (
            <AudioVisualizer isPlaying={isPlaying} barCount={3} className="justify-center" />
          ) : (
            <span>
              {typeof index === "number" ? (
                index + 1
              ) : (
                <Play className="w-3.5 h-3.5 mx-auto opacity-0 group-hover:opacity-100 fill-current" />
              )}
            </span>
          )}
        </div>

        {/* Artwork */}
        <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-xl overflow-hidden shrink-0 bg-zinc-900 border border-white/[0.08]">
          {track.artworkUrl ? (
            <img src={track.artworkUrl} alt={track.title} className="w-full h-full object-cover" loading="lazy" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Music className="w-5 h-5 text-zinc-500" />
            </div>
          )}
          <div
            className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${
              isCurrent ? "opacity-100" : "opacity-0 group-hover:opacity-100"
            }`}
          >
            {isCurrent && isPlaying ? (
              <Pause className="w-4 h-4 fill-white text-white" />
            ) : (
              <Play className="w-4 h-4 fill-white text-white ml-0.5" />
            )}
          </div>
        </div>

        {/* Title and Artist */}
        <div className="min-w-0 flex-1 text-right">
          <div className="flex items-center gap-2">
            <span
              className={`text-xs sm:text-sm font-bold truncate ${
                isCurrent ? "text-emerald-300 font-bold" : "text-white group-hover:text-emerald-300"
              }`}
            >
              {track.title}
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-zinc-400 truncate mt-0.5 font-medium">
            <span>{track.artistName}</span>
            {track.albumName && <span className="hidden md:inline text-zinc-500">• {track.albumName}</span>}
          </div>
        </div>
      </div>

      {/* Right Controls: Full badge, Duration, Favorite, Menu */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <span className="hidden lg:inline text-[10px] text-zinc-400 bg-white/[0.04] px-2.5 py-0.5 rounded-md border border-white/[0.06] font-medium">
          {track.genre || "موسيقى"}
        </span>

        <span className="text-[10px] text-emerald-300 bg-emerald-950/80 border border-emerald-600/40 px-2.5 py-0.5 rounded-full flex items-center gap-1 font-bold shadow-sm">
          <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
          كاملة {track.fullDurationSeconds ? `(${formatDuration(track.fullDurationSeconds)})` : ""}
        </span>

        {/* Favorite Heart */}
        <button
          onClick={handleFavClick}
          className="p-1.5 text-zinc-400 hover:text-rose-500 transition-colors rounded-full"
          title={isFav ? "إزالة من المفضلة" : "إضافة للمفضلة"}
        >
          <Heart className={`w-4 h-4 ${isFav ? "fill-rose-500 text-rose-500" : ""}`} />
        </button>

        {/* Three dots menu */}
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
            className="p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-white/[0.06] transition"
            title="خيارات إضافية"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {showMenu && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="absolute left-0 top-full mt-1.5 w-52 bg-[#161622] border border-white/[0.1] rounded-2xl p-1.5 shadow-2xl z-30 flex flex-col gap-1 text-xs text-zinc-300 animate-in fade-in"
            >
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  playTrack(track, trackList || [track], "full");
                  setShowMenu(false);
                }}
                className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/[0.06] text-right w-full text-emerald-400 font-bold"
              >
                <Play className="w-4 h-4 fill-emerald-400" />
                <span>تشغيل الأغنية كاملة</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  openSourceModal(track);
                  setShowMenu(false);
                }}
                className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/[0.06] text-right w-full text-zinc-300"
              >
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>خيارات ومصادر الاستماع...</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  addToQueue(track);
                  setShowMenu(false);
                }}
                className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/[0.06] text-right w-full"
              >
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>إضافة لقائمة الانتظار</span>
              </button>

              {onAddToPlaylist && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddToPlaylist(track);
                    setShowMenu(false);
                  }}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/[0.06] text-right w-full"
                >
                  <Plus className="w-4 h-4 text-indigo-400" />
                  <span>إضافة لقائمة تشغيل...</span>
                </button>
              )}

              <button
                onClick={handleCopyLink}
                className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/[0.06] text-right w-full"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                <span>{copied ? "تم نسخ الرابط" : "مشاركة الأغنية"}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
