"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import {
  Search,
  Music,
  Disc3,
  Mic2,
  Compass,
  Heart,
  Layers,
  Sparkles,
  X,
  Flame,
  Headphones,
  Download,
  ArrowDownToLine,
  Smartphone,
} from "lucide-react";

export function Navbar() {
  const router = useRouter();
  const pathname = usePathname();
  const [searchQuery, setSearchQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const [totalSongsCount, setTotalSongsCount] = useState<number | null>(null);

  useEffect(() => {
    fetch("/api/stats")
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data?.totalTracks) {
          setTotalSongsCount(data.data.totalTracks);
        }
      })
      .catch(() => {});
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const navLinks = [
    { href: "/", label: "الرئيسية", icon: Compass },
    { href: "/genres", label: "الأنواع والتصنيفات", icon: Layers },
    { href: "/artists", label: "المطربون والنجوم", icon: Mic2 },
    { href: "/albums", label: "الألبومات", icon: Disc3 },
    { href: "/library", label: "مكتبتي الموسيقية", icon: Heart },
    { href: "/download", label: "صفحة التحميل", icon: Smartphone },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#060608]/85 backdrop-blur-xl border-b border-white/[0.07] px-3 sm:px-6 lg:px-8 py-3 transition-all duration-300 shadow-2xl shadow-black/50">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* Logo & Brand with Ambient Glow */}
        <Link href="/" className="flex items-center gap-2.5 sm:gap-3 group shrink-0">
          <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/25 group-hover:shadow-emerald-500/40 group-hover:scale-105 transition-all duration-300">
            <Music className="w-5 h-5 sm:w-6 sm:h-6 text-zinc-950 font-black" />
            <div className="absolute inset-0 rounded-2xl bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="text-xl sm:text-2xl font-black bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-200 bg-clip-text text-transparent tracking-tight">
                نـغــم
              </span>
              <span className="text-[10px] sm:text-[11px] uppercase tracking-widest text-zinc-400 font-bold bg-white/[0.06] px-1.5 sm:px-2 py-0.5 rounded-md border border-white/[0.08]">
                Nagham
              </span>
            </div>
            <span className="text-[10px] text-zinc-400 hidden sm:inline font-medium">عالم الموسيقى العربية والمصرية الكبرى</span>
          </div>
        </Link>

        {/* Center Search Bar with Glass Glow */}
        <form onSubmit={handleSearchSubmit} className="flex-1 max-w-md mx-1 sm:mx-2 relative">
          <div
            className={`relative flex items-center transition-all duration-300 rounded-full ${
              isFocused ? "ring-2 ring-emerald-500/40 shadow-lg shadow-emerald-500/10" : ""
            }`}
          >
            <Search className="w-4 h-4 text-zinc-400 absolute right-3.5 pointer-events-none transition-colors group-focus-within:text-emerald-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder="ابحث عن أي أغنية، مطرب، ألبوم، طرب، شعبي، أو راب..."
              className="w-full bg-[#121218]/90 hover:bg-[#181822] focus:bg-[#1a1a24] text-xs sm:text-sm text-zinc-100 placeholder-zinc-500 rounded-full pr-10 pl-9 py-2.5 border border-white/[0.08] focus:border-emerald-500/60 focus:outline-none transition-all duration-300"
              dir="rtl"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="absolute left-3 text-zinc-400 hover:text-zinc-200 p-1 rounded-full bg-zinc-800/80 hover:bg-zinc-700 transition"
                title="مسح"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </form>

        {/* Total Song Count Badge Icon */}
        <Link
          href="/search"
          className="group relative flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-2xl bg-gradient-to-r from-[#14141e] to-[#1c1c2a] border border-emerald-500/30 hover:border-emerald-400 transition-all duration-300 shadow-lg shadow-black/50 hover:shadow-emerald-950/30 shrink-0"
          title="إجمالي عدد الأغاني الكاملة المتوفرة في التطبيق"
        >
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <Headphones className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400 animate-pulse" />
          </div>
          <div className="flex flex-col text-right leading-none">
            <span className="text-[9px] sm:text-[10px] text-zinc-400 font-medium hidden xs:inline">إجمالي الأغاني</span>
            <div className="flex items-center gap-1 mt-0.5">
              <span className="text-xs sm:text-sm font-black text-emerald-300">
                {totalSongsCount ? `${totalSongsCount.toLocaleString("ar-EG")}+` : "4,690+"}
              </span>
              <span className="text-[10px] text-zinc-400 font-bold hidden sm:inline">أغنية</span>
            </div>
          </div>
        </Link>

        {/* Direct APK Download Link */}
        <a
          href="/Nagham-Music-v2.0.apk"
          download="Nagham-Music-v2.0.apk"
          className="group flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-black text-xs sm:text-sm shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/40 hover:scale-105 active:scale-95 transition-all duration-200 shrink-0 cursor-pointer"
          title="انقر هنا لتحميل ملف APK مباشرة لجهاز الأندرويد"
        >
          <ArrowDownToLine className="w-4 h-4 stroke-[2.5]" />
          <span>تحميل APK</span>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1.5 text-xs font-medium">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all duration-200 ${
                  isActive
                    ? "bg-gradient-to-r from-emerald-500/15 to-teal-500/10 text-emerald-400 border border-emerald-500/30 font-bold shadow-md shadow-emerald-950/20"
                    : "text-zinc-300 hover:text-white hover:bg-white/[0.06] border border-transparent"
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? "text-emerald-400" : "text-zinc-400"}`} />
                <span>{link.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
