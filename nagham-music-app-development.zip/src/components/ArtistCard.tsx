"use client";

import React from "react";
import Link from "next/link";
import { Artist } from "@/lib/types";
import { Mic2, CheckCircle2, Sparkles } from "lucide-react";

interface ArtistCardProps {
  artist: Artist;
}

export function ArtistCard({ artist }: ArtistCardProps) {
  const displayName = artist.nameAr || artist.name;

  return (
    <Link
      href={`/artists/${encodeURIComponent(artist.id || artist.name)}`}
      className="group relative flex flex-col items-center text-center p-3.5 sm:p-4 rounded-3xl bg-[#121218]/70 hover:bg-[#1a1a24] border border-white/[0.06] hover:border-emerald-500/40 transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-emerald-950/20"
    >
      {/* Circular Avatar with Glowing Ring */}
      <div className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-full overflow-hidden bg-zinc-900 mb-3.5 shadow-xl border-2 border-white/[0.1] group-hover:border-emerald-400 group-hover:shadow-emerald-500/20 transition-all duration-500">
        {artist.imageUrl ? (
          <img
            src={artist.imageUrl}
            alt={displayName}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-zinc-900">
            <Mic2 className="w-10 h-10 text-zinc-500" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Artist Info */}
      <div className="flex items-center gap-1.5 justify-center max-w-full px-1">
        <h4 className="text-sm sm:text-base font-bold text-zinc-100 group-hover:text-emerald-300 transition-colors duration-200 truncate">
          {displayName}
        </h4>
        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
      </div>

      {artist.nameAr && artist.name !== artist.nameAr && (
        <span className="text-[11px] text-zinc-400 truncate max-w-full mt-0.5">{artist.name}</span>
      )}

      <div className="flex items-center gap-2 mt-2.5">
        <span className="text-[10px] text-zinc-300 bg-white/[0.06] px-2.5 py-0.5 rounded-full border border-white/[0.06] font-medium">
          {artist.genre}
        </span>
        <span className="text-[10px] text-emerald-400 font-bold">{artist.monthlyListeners}</span>
      </div>
    </Link>
  );
}
