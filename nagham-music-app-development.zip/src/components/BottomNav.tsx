"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Layers, Search, Mic2, Heart, ArrowDownToLine } from "lucide-react";

export function BottomNav() {
  const pathname = usePathname();

  const links = [
    { href: "/", label: "الرئيسية", icon: Home },
    { href: "/genres", label: "الأنواع", icon: Layers },
    { href: "/search", label: "البحث", icon: Search },
    { href: "/artists", label: "المطربون", icon: Mic2 },
    { href: "/library", label: "مكتبتي", icon: Heart },
    { href: "/download", label: "APK أوفلاين", icon: ArrowDownToLine },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#060608]/92 backdrop-blur-2xl border-t border-white/[0.08] px-2 py-1 safe-area-pb shadow-2xl shadow-black">
      <div className="flex items-center justify-around">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));

          return (
            <Link
              key={link.href}
              href={link.href}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-2xl transition-all duration-200 ${
                isActive ? "text-emerald-400 font-bold scale-105" : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              <div
                className={`p-1 rounded-xl transition-all duration-200 ${
                  isActive
                    ? "bg-gradient-to-tr from-emerald-500/20 to-teal-500/10 border border-emerald-500/30 shadow-md shadow-emerald-500/10"
                    : ""
                }`}
              >
                <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${isActive ? "text-emerald-400" : "text-zinc-400"}`} />
              </div>
              <span className="text-[9px] sm:text-[10px] mt-0.5 tracking-tight font-medium">{link.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
