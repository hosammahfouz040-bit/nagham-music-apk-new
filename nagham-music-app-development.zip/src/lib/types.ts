export type GenreCategory =
  | "all"
  | "tarab"
  | "shaabi"
  | "mahraganat"
  | "romantic"
  | "rap"
  | "rock"
  | "pop"
  | "calm"
  | "world"
  | "khaleeji";

export type MusicLanguage = "all" | "arabic" | "international";

export type TrackPlaybackType = "full_stream" | "youtube_official" | "preview_only" | "external_only";

export type ActivePlayerMode = "preview" | "full";

export interface Track {
  id: string; // unique ID
  trackId: string;
  title: string;
  artistName: string;
  artistId?: string;
  albumName: string;
  albumId?: string;
  artworkUrl: string;
  previewUrl: string; // Official 30s sample preview
  fullStreamUrl?: string | null; // Direct legal stream (e.g. Archive open music / direct stream)
  youtubeVideoId?: string | null; // Verified official YouTube ID for full in-app player
  durationSeconds: number; // Duration of audio stream in seconds
  fullDurationSeconds?: number | null; // Actual full track duration in seconds
  playbackType?: TrackPlaybackType;
  isFullPlayable?: boolean; // True if can be played full length in-app
  externalAppleMusicUrl?: string | null;
  externalDeezerUrl?: string | null;
  externalSpotifyUrl?: string | null;
  externalYoutubeUrl?: string | null;
  externalAnghamiUrl?: string | null;
  genre: string;
  genreCategory: GenreCategory;
  language: "arabic" | "international";
  releaseDate?: string;
  lyrics?: string | null;
  playCount?: number;
  isFeatured?: boolean;
  isTrending?: boolean;
  source?: "itunes" | "deezer" | "curated" | "archive" | "youtube";
}

export interface Artist {
  id: string;
  name: string;
  nameAr?: string | null;
  imageUrl: string;
  bio?: string;
  genre: string;
  genreCategory: GenreCategory;
  language: "arabic" | "international";
  monthlyListeners: string;
  isPopular?: boolean;
  tracksCount?: number;
}

export interface Album {
  id: string;
  title: string;
  artistName: string;
  artistId?: string;
  coverUrl: string;
  releaseYear: string;
  genre: string;
  genreCategory: GenreCategory;
  language: "arabic" | "international";
  totalTracks: number;
  tracks?: Track[];
}

export interface Playlist {
  id: string;
  name: string;
  description?: string;
  coverUrl?: string;
  isSystem?: boolean;
  genreCategory?: GenreCategory;
  tracks?: Track[];
  trackCount?: number;
  createdAt?: string;
}

export interface PlaylistItem {
  id: number;
  playlistId: string;
  trackId: string;
  title: string;
  artistName: string;
  albumName?: string;
  artworkUrl?: string;
  previewUrl: string;
  youtubeVideoId?: string | null;
  fullStreamUrl?: string | null;
  isFullPlayable?: boolean;
  fullDurationSeconds?: number | null;
  playbackType?: TrackPlaybackType;
  durationSeconds: number;
  position: number;
}

export interface FavoriteItem {
  id: number;
  trackId: string;
  title: string;
  artistName: string;
  albumName?: string;
  artworkUrl?: string;
  previewUrl: string;
  youtubeVideoId?: string | null;
  fullStreamUrl?: string | null;
  isFullPlayable?: boolean;
  fullDurationSeconds?: number | null;
  playbackType?: TrackPlaybackType;
  durationSeconds: number;
  genre?: string;
  genreCategory?: GenreCategory;
  language?: "arabic" | "international";
  externalAppleMusicUrl?: string;
  externalDeezerUrl?: string;
  externalSpotifyUrl?: string;
  externalYoutubeUrl?: string;
  externalAnghamiUrl?: string;
  createdAt: string;
}

export interface ListeningHistoryItem {
  id: number;
  trackId: string;
  title: string;
  artistName: string;
  albumName?: string;
  artworkUrl?: string;
  previewUrl: string;
  durationSeconds: number;
  genre?: string;
  playedAt: string;
}

export interface SearchResult {
  tracks: Track[];
  artists: Artist[];
  albums: Album[];
  playlists: Playlist[];
  totalResults: number;
}

export interface GenreInfo {
  id: GenreCategory;
  title: string;
  titleEn: string;
  description: string;
  icon: string;
  color: string;
  bgGradient: string;
  language: "arabic" | "international" | "both";
  featuredArtists: string[];
}
