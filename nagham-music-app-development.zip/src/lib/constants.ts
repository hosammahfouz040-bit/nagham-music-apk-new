import { GenreInfo } from "./types";

export const GENRES: GenreInfo[] = [
  {
    id: "tarab",
    title: "طرب أصيل",
    titleEn: "Tarab Classics",
    description: "روائع الزمن الجميل، عمالقة الغناء العربي، ألحان خالدة وكلمات عميقة",
    icon: "Mic2",
    color: "#EAB308", // Amber
    bgGradient: "from-amber-950/80 via-yellow-900/40 to-black",
    language: "arabic",
    featuredArtists: ["أم كلثوم", "عبد الحليم حافظ", "فيروز", "وردة الجزائرية", "صباح فخري", "وديع الصافي"],
  },
  {
    id: "shaabi",
    title: "شعبي مصري وعربي",
    titleEn: "Shaabi Music",
    description: "الإيقاعات الشعبية الأصيلة، مواويل الحارة، وأشهر أغاني الأفراح",
    icon: "Flame",
    color: "#F97316", // Orange
    bgGradient: "from-orange-950/80 via-red-900/40 to-black",
    language: "arabic",
    featuredArtists: ["أحمد عدوية", "حكيم", "رضا البحراوي", "عبد الباسط حمودة", "طارق الشيخ"],
  },
  {
    id: "mahraganat",
    title: "مهرجانات وترند",
    titleEn: "Mahraganat & Viral",
    description: "أحدث مهرجانات الشارع، إيقاعات إلكترونية سريعة وأغاني تصدرت الترند",
    icon: "Sparkles",
    color: "#EC4899", // Pink
    bgGradient: "from-pink-950/80 via-rose-900/40 to-black",
    language: "arabic",
    featuredArtists: ["عصام صاصا", "حسن شاكوش", "عمر ككمال", "مسلم", "عنبة", "حمو بيكا"],
  },
  {
    id: "romantic",
    title: "رومانسي وإحساس",
    titleEn: "Romantic & Emotional",
    description: "أغاني الحب والمشاعر، هدوء القلوب، وأعذب الكلمات والألحان الرقيقة",
    icon: "Heart",
    color: "#EF4444", // Red
    bgGradient: "from-rose-950/80 via-pink-900/40 to-black",
    language: "both",
    featuredArtists: ["شيرين عبد الوهاب", "إليسا", "تامر حسني", "أصالة نصري", "مروان خوري", "وائل كفوري"],
  },
  {
    id: "rap",
    title: "راب وهيب هوب",
    titleEn: "Rap & Hip-Hop",
    description: "قوافي الراب العربي والعالمي، أقوى التراكات، وإيقاعات التراب المعاصرة",
    icon: "Radio",
    color: "#8B5CF6", // Purple
    bgGradient: "from-purple-950/80 via-indigo-900/40 to-black",
    language: "both",
    featuredArtists: ["ويجز", "مروان بابلو", "الجوكر", "Eminem", "Drake", "Travis Scott", "Kendrick Lamar"],
  },
  {
    id: "pop",
    title: "بوب حديث",
    titleEn: "Modern Pop",
    description: "أشهر الأغاني الضاربة، أفضل إنتاجات البوب العربي والعالمي الحديث",
    icon: "Disc3",
    color: "#06B6D4", // Cyan
    bgGradient: "from-cyan-950/80 via-blue-900/40 to-black",
    language: "both",
    featuredArtists: ["عمرو دياب", "نانسي عجرم", "محمد حماقي", "The Weeknd", "Taylor Swift", "Dua Lipa"],
  },
  {
    id: "khaleeji",
    title: "خليجي وعراقي",
    titleEn: "Khaleeji & Iraqi",
    description: "عذوبة الأوتار الخليجية وشجن الأغنية العراقية مع كبار النجوم",
    icon: "Music",
    color: "#10B981", // Emerald
    bgGradient: "from-emerald-950/80 via-teal-900/40 to-black",
    language: "arabic",
    featuredArtists: ["محمد عبده", "ماجد المهندس", "راشد الماجد", "كاظم الساهر", "سيف نبيل", "أصيل هميم"],
  },
  {
    id: "rock",
    title: "روك وكلاسيك",
    titleEn: "Rock & Classic",
    description: "كلاسيكيات الروك، الجيتارات الكهربائية، وأعظم فرق التاريخ الموسيقي",
    icon: "Guitar",
    color: "#64748B", // Slate
    bgGradient: "from-slate-900/90 via-zinc-900/50 to-black",
    language: "international",
    featuredArtists: ["Queen", "Coldplay", "Imagine Dragons", "Pink Floyd", "Linkin Park", "The Beatles"],
  },
  {
    id: "calm",
    title: "موسيقى هادئة واسترخاء",
    titleEn: "Chill & Instrumental",
    description: "معزوفات بيانو وعود وقانون، موسيقى Lo-Fi للدراسة والتركيز والاسترخاء التام",
    icon: "Coffee",
    color: "#14B8A6", // Teal
    bgGradient: "from-teal-950/80 via-slate-900/40 to-black",
    language: "both",
    featuredArtists: ["Ludovico Einaudi", "Yiruma", "تقاسيم عود شرقية", "Lofi Beats", "Ambient Piano"],
  },
  {
    id: "world",
    title: "موسيقى عالمية ولاتينية",
    titleEn: "World & Global Beats",
    description: "موسيقى الشعوب، الإيقاعات اللاتينية، الأفرو بيتس، والألحان التراثية العالمية",
    icon: "Globe",
    color: "#F59E0B", // Amber
    bgGradient: "from-amber-950/80 via-emerald-900/40 to-black",
    language: "international",
    featuredArtists: ["Rosalía", "Rema", "Burna Boy", "Gipsy Kings", "Luis Fonsi", "Master KG"],
  },
];

export const APP_CONFIG = {
  name: "نغم | Nagham",
  tagline: "منصة استكشاف وتشغيل الموسيقى العربية والعالمية",
  description: "استمع إلى أفضل الأغاني العربية والأجنبية مع معاينات عالية الجودة، وتصنيفات طرب وشعبي وراب وبوب وروك وموسيقى هادئة.",
  version: "1.0.0",
};
