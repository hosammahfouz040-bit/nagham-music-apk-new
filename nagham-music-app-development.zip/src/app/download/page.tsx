"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import {
  Smartphone,
  WifiOff,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  Zap,
  ArrowDownToLine,
  ChevronLeft,
  Share2,
  Check,
  FileCheck,
  AlertTriangle,
  HelpCircle,
  Laptop,
  CheckCheck,
  ExternalLink,
  Info,
} from "lucide-react";

export default function DownloadPage() {
  const [copiedLink, setCopiedLink] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isPwaInstalled, setIsPwaInstalled] = useState(false);
  const [activeTab, setActiveTab] = useState<"instant" | "samsung" | "chrome">("instant");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const isStandalone =
        window.matchMedia("(display-mode: standalone)").matches ||
        (window.navigator as any).standalone === true;
      setIsPwaInstalled(isStandalone);

      window.addEventListener("beforeinstallprompt", (e: any) => {
        e.preventDefault();
        setDeferredPrompt(e);
      });
    }
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setIsPwaInstalled(true);
      }
      setDeferredPrompt(null);
    } else {
      // Trigger instruction scroll
      const el = document.getElementById("install-guide-section");
      el?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: "تطبيق نغم | Nagham لهاتف سامسونج A04",
          text: "ثبّت تطبيق نغم للاستماع إلى آلاف الأغاني العربية والمصرية كاملة وبدون إنترنت!",
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <div className="flex flex-col gap-8 max-w-5xl mx-auto py-2">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-zinc-400 font-medium">
        <Link href="/" className="hover:text-emerald-400 transition">الرئيسية</Link>
        <ChevronLeft className="w-3.5 h-3.5 rtl:rotate-180 text-zinc-600" />
        <span className="text-white font-bold">تثبيت تطبيق نغم على هاتف سامسونج A04 وAndroid</span>
      </div>

      {/* Crucial Explanation of Parse Error & Direct Solution */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/60 via-[#181824] to-emerald-950/40 border border-amber-500/40 shadow-2xl flex flex-col gap-4 text-right">
        <div className="flex items-start gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
            <AlertTriangle className="w-6 h-6 animate-pulse" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-amber-300 bg-amber-950/80 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                حل مشكلة «حدث خطأ أثناء تحليل الحزمة» على سامسونج A04
              </span>
            </div>
            <h2 className="text-base sm:text-lg font-black text-white">
              لماذا ظهرت لك رسالة خطأ تحليل الحزمة؟ وكيف تثبت التطبيق بنجاح 100%؟
            </h2>
            <p className="text-xs sm:text-sm text-zinc-300 mt-2 leading-relaxed">
              هواتف سامسونج الحديثة بنظام أندرويد (مثل <strong>Samsung Galaxy A04</strong> بنظام One UI) تمنع التثبيت اليدوي للملفات الخارجية غير الموقعة بشهادة Google Play وتظهر رسالة «خطأ في تحليل الحزمة».
              <br className="hidden sm:inline" />
              <strong>الحل المعتمد والمثالي:</strong> هو التثبيت الفوري عبر ميزة <strong>التثبيت المباشر (WebAPK)</strong> التي يبنيها نظام سامسونج تلقائياً على هاتفك بنقرة واحدة فقط، ليعمل التطبيق كـ <strong>تطبيق رسمي كامل بشاشة كاملة وبدون إنترنت (أوفلاين)</strong> وبدون أي أخطاء!
            </p>
          </div>
        </div>

        {/* Big One-Click Install Button */}
        <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={handleInstallClick}
            className="w-full sm:w-auto flex-1 py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 hover:from-emerald-400 hover:to-cyan-300 text-zinc-950 font-black text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-xl shadow-emerald-500/30 hover:scale-[1.02] active:scale-95 transition-all"
          >
            <Smartphone className="w-5 h-5 stroke-[2.5]" />
            <span>{isPwaInstalled ? "التطبيق مثبت على جهازك ✓ (انقر للفتح)" : "اضغط هنا لتثبيت التطبيق على هاتف سامسونج A04 الآن"}</span>
          </button>

          <button
            onClick={handleShare}
            className="w-full sm:w-auto p-4 rounded-2xl bg-[#1e1e2c] hover:bg-[#28283a] text-zinc-200 text-xs font-bold border border-white/[0.08] flex items-center justify-center gap-2 transition"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            <span>مشاركة الرابط</span>
          </button>
        </div>
      </div>

      {/* Visual Step-by-Step Installation Guides */}
      <div id="install-guide-section" className="p-6 sm:p-8 rounded-3xl bg-[#121218]/90 border border-white/[0.08] text-right shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.08] pb-5 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                خطوات التثبيت السريعة حسب المتصفح في هاتف سامسونج A04:
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">اختر المتصفح المفتوح لديك الآن لإتمام التثبيت في ثانيتين:</p>
            </div>
          </div>

          {/* Browser Switcher Tabs */}
          <div className="flex items-center gap-1.5 bg-[#181824] p-1.5 rounded-2xl border border-white/[0.06] text-xs font-bold">
            <button
              onClick={() => setActiveTab("instant")}
              className={`px-4 py-2 rounded-xl transition-all ${
                activeTab === "instant"
                  ? "bg-emerald-500 text-zinc-950 font-black shadow-md shadow-emerald-500/20"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              متصفح سامسونج إنترنت
            </button>
            <button
              onClick={() => setActiveTab("chrome")}
              className={`px-4 py-2 rounded-xl transition-all ${
                activeTab === "chrome"
                  ? "bg-emerald-500 text-zinc-950 font-black shadow-md shadow-emerald-500/20"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              متصفح كروم (Chrome)
            </button>
          </div>
        </div>

        {/* Tab 1: Samsung Internet (Pre-installed on Samsung A04) */}
        {activeTab === "instant" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-zinc-300 animate-in fade-in">
            <div className="p-5 rounded-3xl bg-[#181826]/80 border border-white/[0.08] flex flex-col gap-3 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-zinc-950 font-black flex items-center justify-center text-xs">
                  1
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md">
                  الخطوة الأولى
                </span>
              </div>
              <h4 className="font-bold text-white text-base">اضغط على زر القائمة (☰)</h4>
              <p className="text-xs text-zinc-300 leading-relaxed">
                في متصفح سامسونج إنترنت أسفل الشاشة، اضغط على زر الخطوط الثلاثة <strong>(☰)</strong> في الزاوية السفلى.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-[#181826]/80 border border-white/[0.08] flex flex-col gap-3 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-zinc-950 font-black flex items-center justify-center text-xs">
                  2
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md">
                  الخطوة الثانية
                </span>
              </div>
              <h4 className="font-bold text-white text-base">اضغط «إضافة صفحة إلى»</h4>
              <p className="text-xs text-zinc-300 leading-relaxed">
                اختر <strong>«إضافة صفحة إلى ➔ الشاشة الرئيسية»</strong> أو انقر على <strong>«تثبيت التطبيق»</strong> إذا ظهرت لك.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-[#181826]/80 border border-white/[0.08] flex flex-col gap-3 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-zinc-950 font-black flex items-center justify-center text-xs">
                  3
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md">
                  تم التثبيت
                </span>
              </div>
              <h4 className="font-bold text-white text-base">افتح التطبيق واستمتع!</h4>
              <p className="text-xs text-zinc-300 leading-relaxed">
                مبروك! سيظهر تطبيق <strong>«نغم | Nagham»</strong> في قائمة تطبيقات هاتفك Samsung A04 ويعمل بكامل الشاشة وبدون إنترنت.
              </p>
            </div>
          </div>
        )}

        {/* Tab 2: Google Chrome */}
        {activeTab === "chrome" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-zinc-300 animate-in fade-in">
            <div className="p-5 rounded-3xl bg-[#181826]/80 border border-white/[0.08] flex flex-col gap-3 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-zinc-950 font-black flex items-center justify-center text-xs">
                  1
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md">
                  الخطوة الأولى
                </span>
              </div>
              <h4 className="font-bold text-white text-base">اضغط على النقاط الثلاث (⋮)</h4>
              <p className="text-xs text-zinc-300 leading-relaxed">
                في متصفح Google Chrome أعلى الشاشة، اضغط على زر النقاط الثلاث <strong>(⋮)</strong> لفتح قائمة الخيارات.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-[#181826]/80 border border-white/[0.08] flex flex-col gap-3 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-zinc-950 font-black flex items-center justify-center text-xs">
                  2
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md">
                  الخطوة الثانية
                </span>
              </div>
              <h4 className="font-bold text-white text-base">اختر «تثبيت التطبيق»</h4>
              <p className="text-xs text-zinc-300 leading-relaxed">
                اضغط على خيار <strong>«تثبيت التطبيق / Install App»</strong> أو <strong>«الإضافة إلى الشاشة الرئيسية»</strong> ثم اضغط تثبيت.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-[#181826]/80 border border-white/[0.08] flex flex-col gap-3 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-zinc-950 font-black flex items-center justify-center text-xs">
                  3
                </span>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md">
                  تم التثبيت
                </span>
              </div>
              <h4 className="font-bold text-white text-base">تطبيق مستقل كامل</h4>
              <p className="text-xs text-zinc-300 leading-relaxed">
                يقوم أندرويد بإنشاء التطبيق الأصلي على جهازك ليعمل بدون متصفح، مع إمكانية التشغيل في الخلفية وبدون إنترنت!
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Features of Nagham on Android */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-[#121218]/70 border border-white/[0.08] shadow-lg flex flex-col gap-2.5 text-right">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <WifiOff className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-white text-base">تشغيل بدون إنترنت (Offline)</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            يتم حفظ الأغاني والمكتبة تلقائياً في ذاكرة الهاتف لتستمتع بها في أي وقت حتى في وضع الطيران.
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-[#121218]/70 border border-white/[0.08] shadow-lg flex flex-col gap-2.5 text-right">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-white text-base">أغاني كاملة لجميع المطربين</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            أكثر من 4,690+ أغنية كاملة من البداية للنهاية (شفيقة، منير، عبد الحليم، عمرو دياب، كايروكي، وغيرهم).
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-[#121218]/70 border border-white/[0.08] shadow-lg flex flex-col gap-2.5 text-right">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            <Zap className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-white text-base">سريع وخفيف على سامسونج A04</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            مصمم ومُحسّن خصيصاً ليعمل بسلاسة تامة دون استهلاك موارد المعالج أو بطارية الهاتف.
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-[#121218]/70 border border-white/[0.08] shadow-lg flex flex-col gap-2.5 text-right">
          <div className="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-white text-base">تشغيل في الخلفية وشاشة القفل</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            تحكم كامل في الأغاني والانتقال ومؤقت النوم مباشرة من ستارة الإشعارات وشاشة القفل.
          </p>
        </div>
      </div>
    </div>
  );
}
