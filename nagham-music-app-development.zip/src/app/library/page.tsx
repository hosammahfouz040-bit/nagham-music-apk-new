"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Track, Playlist, FavoriteItem, ListeningHistoryItem } from "@/lib/types";
import { usePlayer } from "@/context/PlayerContext";
import { TrackCard } from "@/components/TrackCard";
import { PlaylistModal } from "@/components/PlaylistModal";
import {
  Heart,
  ListMusic,
  Clock,
  Plus,
  Play,
  Shuffle,
  Trash2,
  Disc3,
  Sparkles,
  Music,
  Flame,
} from "lucide-react";

export default function LibraryPage() {
  const { playTrack, queue, clearQueue } = usePlayer();
  const [activeTab, setActiveTab] = useState<"favorites" | "playlists" | "history" | "queue">("favorites");

  const [favorites, setFavorites] = useState<Track[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [history, setHistory] = useState<ListeningHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);
  const [selectedTrackForPlaylist, setSelectedTrackForPlaylist] = useState<Track | null>(null);

  useEffect(() => {
    loadLibraryData();
  }, [activeTab]);

  const loadLibraryData = async () => {
    setLoading(true);
    try {
      if (activeTab === "favorites") {
        const res = await fetch("/api/favorites");
        const data = await res.json();
        if (data.success && Array.isArray(data.data)) {
          setFavorites(data.data);
        }
      } else if (activeTab === "playlists") {
        const res = await fetch("/api/playlists");
        const data = await res.json();
        if (data.success && Array.isArray(data.data)) {
          setPlaylists(data.data);
        }
      } else if (activeTab === "history") {
        const res = await fetch("/api/history");
        const data = await res.json();
        if (data.success && Array.isArray(data.data)) {
          setHistory(data.data);
        }
      }
    } catch (err) {
      console.warn("Network error loading library, checking local offline database:", err);
      try {
        if (activeTab === "favorites") {
          const { getOfflineFavorites } = await import("@/lib/offline-store");
          const localFavs = await getOfflineFavorites();
          setFavorites(localFavs);
        }
      } catch (offlineErr) {
        console.error("Local library read error:", offlineErr);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (!confirm("هل أنت متأكد من مسح سجل الاستماع بالكامل؟")) return;
    try {
      await fetch("/api/history", { method: "DELETE" });
      setHistory([]);
    } catch (err) {
      console.error("Clear history error:", err);
    }
  };

  const handlePlayAllFavorites = (shuffle: boolean = false) => {
    if (favorites.length === 0) return;
    const queueToPlay = shuffle ? [...favorites].sort(() => Math.random() - 0.5) : favorites;
    playTrack(queueToPlay[0], queueToPlay);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-emerald-950/30 border border-white/[0.08] p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
              <Heart className="w-7 h-7 text-zinc-950 fill-zinc-950" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-white">مكتبتي الموسيقية</h1>
              <p className="text-xs sm:text-sm text-zinc-400 mt-1">
                أغانيك المفضلة، قوائم التشغيل الخاصة، وسجل الاستماع الكامل
              </p>
            </div>
          </div>

          {/* Action Button */}
          <button
            onClick={() => {
              setSelectedTrackForPlaylist(null);
              setIsPlaylistModalOpen(true);
            }}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-zinc-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>إنشاء قائمة تشغيل جديدة</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-white/[0.08] pb-3 overflow-x-auto text-xs sm:text-sm font-semibold">
        <button
          onClick={() => setActiveTab("favorites")}
          className={`px-5 py-2.5 rounded-2xl transition-all duration-200 flex items-center gap-2 shrink-0 ${
            activeTab === "favorites"
              ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20"
              : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
          }`}
        >
          <Heart className="w-4 h-4 fill-current" />
          <span>المفضلة ({favorites.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("playlists")}
          className={`px-5 py-2.5 rounded-2xl transition-all duration-200 flex items-center gap-2 shrink-0 ${
            activeTab === "playlists"
              ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20"
              : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
          }`}
        >
          <ListMusic className="w-4 h-4" />
          <span>قوائم التشغيل ({playlists.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("history")}
          className={`px-5 py-2.5 rounded-2xl transition-all duration-200 flex items-center gap-2 shrink-0 ${
            activeTab === "history"
              ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20"
              : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>سجل الاستماع</span>
        </button>

        <button
          onClick={() => setActiveTab("queue")}
          className={`px-5 py-2.5 rounded-2xl transition-all duration-200 flex items-center gap-2 shrink-0 ${
            activeTab === "queue"
              ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20"
              : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>قائمة الانتظار ({queue.length})</span>
        </button>
      </div>

      {/* Tab 1: Favorites */}
      {activeTab === "favorites" && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">{favorites.length} أغنية في المفضلة</span>
            {favorites.length > 0 && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handlePlayAllFavorites(false)}
                  className="px-4 py-2 bg-emerald-500 text-zinc-950 rounded-xl text-xs font-bold flex items-center gap-1.5 hover:bg-emerald-400 shadow-md transition"
                >
                  <Play className="w-4 h-4 fill-zinc-950" />
                  <span>تشغيل المفضلة</span>
                </button>
                <button
                  onClick={() => handlePlayAllFavorites(true)}
                  className="p-2 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-xl hover:text-white transition"
                  title="تشغيل عشوائي"
                >
                  <Shuffle className="w-4 h-4 text-emerald-400" />
                </button>
              </div>
            )}
          </div>

          {loading ? (
            <div className="p-12 text-center text-zinc-500 text-sm">جاري تحميل المفضلة...</div>
          ) : favorites.length === 0 ? (
            <div className="p-16 text-center bg-[#121218]/50 rounded-3xl border border-white/[0.08] flex flex-col items-center gap-3">
              <Heart className="w-12 h-12 text-zinc-600 mb-1" />
              <h3 className="text-base font-bold text-white">لم تقم بإضافة أي أغاني للمفضلة بعد</h3>
              <p className="text-xs text-zinc-400 max-w-sm">
                انقر على أيقونة القلب في أي أغنية أثناء تصفحك لحفظها هنا والرجوع إليها بسهولة.
              </p>
              <Link
                href="/"
                className="mt-2 px-5 py-2.5 rounded-xl bg-emerald-500 text-zinc-950 text-xs font-bold hover:bg-emerald-400 transition"
              >
                استكشف الأغاني الآن
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {favorites.map((track, idx) => (
                <TrackCard
                  key={track.trackId}
                  track={track}
                  trackList={favorites}
                  viewMode="list"
                  index={idx}
                  onAddToPlaylist={(t) => {
                    setSelectedTrackForPlaylist(t);
                    setIsPlaylistModalOpen(true);
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Playlists */}
      {activeTab === "playlists" && (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Create Card */}
            <div
              onClick={() => {
                setSelectedTrackForPlaylist(null);
                setIsPlaylistModalOpen(true);
              }}
              className="group p-6 rounded-3xl bg-[#121218]/40 hover:bg-[#181822] border-2 border-dashed border-white/[0.1] hover:border-emerald-500/50 flex flex-col items-center justify-center gap-3 cursor-pointer min-h-[160px] transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                <Plus className="w-6 h-6" />
              </div>
              <span className="text-sm font-bold text-zinc-200 group-hover:text-emerald-300">
                إنشاء قائمة تشغيل جديدة
              </span>
            </div>

            {/* List of playlists */}
            {playlists.map((pl) => (
              <Link
                key={pl.id}
                href={`/playlists/${pl.id}`}
                className="group p-4 rounded-3xl bg-[#121218]/60 hover:bg-[#181822] border border-white/[0.08] hover:border-emerald-500/30 transition-all duration-300 shadow-lg flex items-center gap-4 cursor-pointer"
              >
                <div className="w-16 h-16 rounded-2xl overflow-hidden bg-zinc-900 shrink-0 border border-white/[0.08]">
                  {pl.coverUrl ? (
                    <img src={pl.coverUrl} alt={pl.name} className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Disc3 className="w-8 h-8 text-zinc-600" />
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1 text-right">
                  <h4 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors truncate">
                    {pl.name}
                  </h4>
                  <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">{pl.description || "قائمة موسيقية"}</p>
                  <span className="text-[10px] text-emerald-400 font-semibold mt-1.5 inline-block bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                    {pl.isSystem ? "رسمية من نغم" : "قائمة مخصصة"}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: History */}
      {activeTab === "history" && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">{history.length} أغنية تم الاستماع إليها</span>
            {history.length > 0 && (
              <button
                onClick={handleClearHistory}
                className="px-3.5 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-rose-400 hover:bg-rose-950/20 text-xs flex items-center gap-1.5 transition font-medium"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>مسح السجل</span>
              </button>
            )}
          </div>

          {loading ? (
            <div className="p-12 text-center text-zinc-500 text-sm">جاري تحميل سجل الاستماع...</div>
          ) : history.length === 0 ? (
            <div className="p-16 text-center bg-[#121218]/40 rounded-3xl border border-white/[0.08] flex flex-col items-center gap-2">
              <Clock className="w-12 h-12 text-zinc-600 mb-1" />
              <h3 className="text-base font-bold text-white">سجل الاستماع فارغ</h3>
              <p className="text-xs text-zinc-400">ستظهر هنا الأغاني التي تستمع إليها تلقائياً.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {history.map((item, idx) => {
                const trackObj: Track = {
                  id: item.trackId,
                  trackId: item.trackId,
                  title: item.title,
                  artistName: item.artistName,
                  albumName: item.albumName || "",
                  artworkUrl: item.artworkUrl || "",
                  previewUrl: item.previewUrl,
                  durationSeconds: item.durationSeconds,
                  genre: item.genre || "موسيقى",
                  genreCategory: "pop",
                  language: "arabic",
                };
                return (
                  <TrackCard
                    key={`${item.id}_${idx}`}
                    track={trackObj}
                    viewMode="list"
                    index={idx}
                    onAddToPlaylist={(t) => {
                      setSelectedTrackForPlaylist(t);
                      setIsPlaylistModalOpen(true);
                    }}
                  />
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Current Queue */}
      {activeTab === "queue" && (
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400 font-medium">{queue.length} أغنية في قائمة الانتظار</span>
            {queue.length > 0 && (
              <button
                onClick={clearQueue}
                className="px-3.5 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white text-xs transition"
              >
                تفريغ القائمة
              </button>
            )}
          </div>

          {queue.length === 0 ? (
            <div className="p-16 text-center bg-[#121218]/40 rounded-3xl border border-white/[0.08] flex flex-col items-center gap-2">
              <Sparkles className="w-12 h-12 text-zinc-600 mb-1" />
              <h3 className="text-base font-bold text-white">قائمة الانتظار فارغة</h3>
              <p className="text-xs text-zinc-400">اختر أي أغنية لتشغيلها وبدء الاستماع المتواصل.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {queue.map((track, idx) => (
                <TrackCard
                  key={`${track.trackId}_queue_${idx}`}
                  track={track}
                  trackList={queue}
                  viewMode="list"
                  index={idx}
                  onAddToPlaylist={(t) => {
                    setSelectedTrackForPlaylist(t);
                    setIsPlaylistModalOpen(true);
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Playlist modal */}
      <PlaylistModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        selectedTrack={selectedTrackForPlaylist}
        onPlaylistCreated={loadLibraryData}
      />
    </div>
  );
}
