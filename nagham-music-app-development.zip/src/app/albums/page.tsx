"use client";

import React, { useState, useEffect } from "react";
import { Album, MusicLanguage } from "@/lib/types";
import { AlbumCard } from "@/components/AlbumCard";
import { Disc3, Search, Sparkles } from "lucide-react";

export default function AlbumsPage() {
  const [albums, setAlbums] = useState<Album[]>([]);
  const [search, setSearch] = useState("");
  const [langFilter, setLangFilter] = useState<MusicLanguage>("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAlbums();
  }, [langFilter]);

  const fetchAlbums = async () => {
    setLoading(true);
    try {
      const langParam = langFilter !== "all" ? `?language=${langFilter}&limit=250` : "?limit=250";
      const res = await fetch(`/api/albums${langParam}`);
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setAlbums(data.data);
      }
    } catch (err) {
      console.error("Error loading albums:", err);
    } finally {
      setLoading(false);
    }
  };

  const filtered = albums.filter((a) => {
    const term = search.toLowerCase();
    return a.title.toLowerCase().includes(term) || a.artistName.toLowerCase().includes(term);
  });

  return (
    <div className="flex flex-col gap-8">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-indigo-950/40 border border-white/[0.08] p-6 sm:p-8 shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/20 shrink-0">
            <Disc3 className="w-7 h-7 text-zinc-950 font-black" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">دليل الألبومات والإصدارات ({albums.length})</h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              استعرض أشهر ألبومات وروائع الموسيقى المصرية، العربية والعالمية
            </p>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center bg-[#121218]/90 p-1 rounded-2xl border border-white/[0.08] text-xs">
          <button
            onClick={() => setLangFilter("all")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 font-bold ${
              langFilter === "all" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20" : "text-zinc-400 hover:text-white"
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setLangFilter("arabic")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 font-bold ${
              langFilter === "arabic" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20" : "text-zinc-400 hover:text-white"
            }`}
          >
            عربي
          </button>
          <button
            onClick={() => setLangFilter("international")}
            className={`px-4 py-2 rounded-xl transition-all duration-200 font-bold ${
              langFilter === "international" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 shadow-md shadow-emerald-500/20" : "text-zinc-400 hover:text-white"
            }`}
          >
            عالمي
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-zinc-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث باسم الألبوم أو المطرب..."
          className="w-full bg-[#121218]/90 text-sm text-white placeholder-zinc-500 rounded-2xl pr-10 pl-4 py-3 border border-white/[0.08] focus:border-emerald-500 outline-none shadow-lg"
        />
      </div>

      {/* Albums Grid */}
      {loading ? (
        <div className="p-12 text-center text-zinc-500 text-sm">جاري تحميل الألبومات...</div>
      ) : filtered.length === 0 ? (
        <div className="p-12 text-center bg-[#121218]/50 rounded-3xl border border-white/[0.08] text-zinc-400">
          لا يوجد ألبوم يطابق بحثك.
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filtered.map((album) => (
            <AlbumCard key={album.id} album={album} />
          ))}
        </div>
      )}
    </div>
  );
}
