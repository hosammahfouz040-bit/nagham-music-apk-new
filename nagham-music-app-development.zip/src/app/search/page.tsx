"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { Track, Artist, Album, Playlist, SearchResult } from "@/lib/types";
import { TrackCard } from "@/components/TrackCard";
import { ArtistCard } from "@/components/ArtistCard";
import { AlbumCard } from "@/components/AlbumCard";
import { PlaylistModal } from "@/components/PlaylistModal";
import {
  Search,
  X,
  Music,
  Mic2,
  Disc3,
  ListMusic,
  Sparkles,
  TrendingUp,
  Flame,
} from "lucide-react";

const SUGGESTIONS = [
  "شفيقة",
  "محمد منير",
  "عبد الحليم حافظ",
  "عمرو دياب",
  "كايروكي",
  "حمزة نمرة",
  "أحمد سعد",
  "الشامي",
  "توليت",
  "فيروز",
  "أم كلثوم",
  "ويجز",
  "شيرين عبد الوهاب",
  "تامر حسني",
  "محمد حماقي",
  "أصالة نصري",
  "كاظم الساهر",
  "ماجد المهندس",
  "حسين الجسمي",
  "عصام صاصا",
  "The Weeknd",
  "Coldplay",
  "Adele",
];

function SearchContent() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get("q") || "";

  const [query, setQuery] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState<"all" | "tracks" | "artists" | "albums" | "playlists">("all");
  const [results, setResults] = useState<SearchResult>({
    tracks: [],
    artists: [],
    albums: [],
    playlists: [],
    totalResults: 0,
  });
  const [loading, setLoading] = useState(false);
  const [selectedTrackForPlaylist, setSelectedTrackForPlaylist] = useState<Track | null>(null);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      performSearch(initialQuery);
    }
  }, [initialQuery]);

  const performSearch = async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      setResults({ tracks: [], artists: [], albums: [], playlists: [], totalResults: 0 });
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(searchTerm.trim())}`);
      const data = await res.json();
      if (data.success && data.data && data.data.totalResults > 0) {
        setResults(data.data);
      } else {
        // Fallback to local offline search
        const { searchOffline } = await import("@/lib/offline-store");
        const offlineRes = await searchOffline(searchTerm);
        if (offlineRes.totalResults > 0) {
          setResults({ ...offlineRes, playlists: [] });
        } else if (data.data) {
          setResults(data.data);
        }
      }
    } catch (err) {
      console.warn("Network search failed, searching local offline catalog:", err);
      try {
        const { searchOffline } = await import("@/lib/offline-store");
        const offlineRes = await searchOffline(searchTerm);
        setResults({ ...offlineRes, playlists: [] });
      } catch (offlineErr) {
        console.error("Offline search failed:", offlineErr);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(query);
  };

  const handleSuggestionClick = (term: string) => {
    setQuery(term);
    performSearch(term);
  };

  const hasResults = results.totalResults > 0;

  return (
    <div className="flex flex-col gap-6">
      {/* Search Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#12121a] via-[#161622] to-emerald-950/30 border border-white/[0.08] p-6 sm:p-8 shadow-2xl flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Search className="w-6 h-6 text-zinc-950 font-black" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">البحث الموسيقي الشامل</h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-0.5">
              ابحث عن أي أغنية مصرية، عربية، أو عالمية، فنان، ألبوم، أو فرقة موسيقية واستمع إليها كاملة
            </p>
          </div>
        </div>

        {/* Big Search Input with Luxury Glow */}
        <form onSubmit={handleFormSubmit} className="relative mt-2">
          <Search className="w-5 h-5 text-zinc-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="اكتب اسم الأغنية أو المطرب (مثال: كايروكي، تملي معاك، الشامي، البخت، Blinding Lights)..."
            className="w-full bg-[#0a0a0e]/95 text-white placeholder-zinc-500 rounded-2xl pr-12 pl-12 py-3.5 sm:py-4 border border-white/[0.12] focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 outline-none text-sm sm:text-base shadow-2xl transition-all duration-300"
            autoFocus
          />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setResults({ tracks: [], artists: [], albums: [], playlists: [], totalResults: 0 });
              }}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white p-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 transition"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </form>

        {/* Popular Query Chips */}
        <div className="flex items-center gap-2 flex-wrap pt-1">
          <span className="text-xs text-zinc-400 flex items-center gap-1 font-semibold">
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            <span>الأكثر بحثاً:</span>
          </span>
          {SUGGESTIONS.map((term) => (
            <button
              key={term}
              onClick={() => handleSuggestionClick(term)}
              className="text-xs bg-[#181824] hover:bg-[#222234] text-zinc-300 hover:text-emerald-300 px-3.5 py-1.5 rounded-xl border border-white/[0.06] hover:border-emerald-500/30 transition-all duration-200"
            >
              {term}
            </button>
          ))}
        </div>
      </div>

      {/* Tabs Filter if search submitted */}
      {hasResults && (
        <div className="flex items-center gap-2 border-b border-white/[0.08] pb-3 overflow-x-auto text-xs sm:text-sm font-semibold">
          <button
            onClick={() => setActiveTab("all")}
            className={`px-5 py-2.5 rounded-2xl transition-all duration-200 ${
              activeTab === "all" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20" : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
            }`}
          >
            الكل ({results.totalResults})
          </button>
          <button
            onClick={() => setActiveTab("tracks")}
            className={`px-5 py-2.5 rounded-2xl transition-all duration-200 flex items-center gap-1.5 ${
              activeTab === "tracks" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20" : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
            }`}
          >
            <Music className="w-4 h-4" />
            <span>الأغاني ({results.tracks.length})</span>
          </button>
          <button
            onClick={() => setActiveTab("artists")}
            className={`px-5 py-2.5 rounded-2xl transition-all duration-200 flex items-center gap-1.5 ${
              activeTab === "artists" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20" : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
            }`}
          >
            <Mic2 className="w-4 h-4" />
            <span>المطربون ({results.artists.length})</span>
          </button>
          <button
            onClick={() => setActiveTab("albums")}
            className={`px-5 py-2.5 rounded-2xl transition-all duration-200 flex items-center gap-1.5 ${
              activeTab === "albums" ? "bg-gradient-to-r from-emerald-500 to-teal-400 text-zinc-950 font-bold shadow-lg shadow-emerald-500/20" : "text-zinc-400 hover:text-white hover:bg-white/[0.04]"
            }`}
          >
            <Disc3 className="w-4 h-4" />
            <span>الألبومات ({results.albums.length})</span>
          </button>
        </div>
      )}

      {/* Results Content */}
      {loading ? (
        <div className="p-16 text-center text-zinc-400 flex flex-col items-center justify-center gap-3">
          <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm">جاري جلب الأغاني والمطربين في أجزاء من الثانية...</p>
        </div>
      ) : !hasResults && query.trim() ? (
        <div className="p-16 text-center bg-[#121218]/40 rounded-3xl border border-white/[0.08] flex flex-col items-center gap-2">
          <Music className="w-12 h-12 text-zinc-600 mb-2" />
          <h3 className="text-base font-bold text-white">لم نجد نتائج مطابقة لـ &quot;{query}&quot;</h3>
          <p className="text-xs text-zinc-400 max-w-md">
            جرّب البحث باسم المطرب باللغة العربية أو الإنجليزية، أو اختر من المقترحات الشائعة بالأعلى.
          </p>
        </div>
      ) : hasResults ? (
        <div className="flex flex-col gap-8">
          {/* Artists Row */}
          {(activeTab === "all" || activeTab === "artists") && results.artists.length > 0 && (
            <section className="flex flex-col gap-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Mic2 className="w-4 h-4 text-emerald-400" />
                <span>المطربون والفنانون المطابقون</span>
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {results.artists.map((artist) => (
                  <ArtistCard key={artist.id} artist={artist} />
                ))}
              </div>
            </section>
          )}

          {/* Tracks List */}
          {(activeTab === "all" || activeTab === "tracks") && results.tracks.length > 0 && (
            <section className="flex flex-col gap-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Music className="w-4 h-4 text-emerald-400" />
                <span>الأغاني الكاملة المكتشفة ({results.tracks.length})</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {results.tracks.map((track, idx) => (
                  <TrackCard
                    key={track.trackId}
                    track={track}
                    trackList={results.tracks}
                    viewMode="list"
                    index={idx}
                    onAddToPlaylist={(t) => {
                      setSelectedTrackForPlaylist(t);
                      setIsPlaylistModalOpen(true);
                    }}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Albums Row */}
          {(activeTab === "all" || activeTab === "albums") && results.albums.length > 0 && (
            <section className="flex flex-col gap-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Disc3 className="w-4 h-4 text-indigo-400" />
                <span>الألبومات</span>
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {results.albums.map((album) => (
                  <AlbumCard key={album.id} album={album} />
                ))}
              </div>
            </section>
          )}
        </div>
      ) : null}

      {/* Playlist modal */}
      <PlaylistModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        selectedTrack={selectedTrackForPlaylist}
      />
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-zinc-500">جاري التحميل...</div>}>
      <SearchContent />
    </Suspense>
  );
}
