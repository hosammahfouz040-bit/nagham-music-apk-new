"use client";

import React, { useState, useEffect } from "react";
import { Artist, GenreCategory, MusicLanguage } from "@/lib/types";
import { ArtistCard } from "@/components/ArtistCard";
import { Mic2, Search, Filter, Sparkles } from "lucide-react";

const GENRE_CHIPS: { id: GenreCategory; label: string }[] = [
  { id: "all", label: "جميع الأقسام" },
  { id: "tarab", label: "طرب أصيل" },
  { id: "pop", label: "بوب حديث" },
  { id: "romantic", label: "رومانسي" },
  { id: "khaleeji", label: "خليجي وعراقي" },
  { id: "shaabi", label: "شعبي" },
  { id: "mahraganat", label: "مهرجانات" },
  { id: "rap", label: "راب وهيب هوب" },
  { id: "world", label: "موسيقى عالمية" },
  { id: "rock", label: "روك" },
  { id: "calm", label: "موسيقى هادئة" },
];

export default function ArtistsPage() {
  const [artists, setArtists] = useState<Artist[]>([]);
  const [search, setSearch] = useState("");
  const [langFilter, setLangFilter] = useState<MusicLanguage>("all");
  const [selectedGenre, setSelectedGenre] = useState<GenreCategory>("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchArtists();
  }, [langFilter, selectedGenre]);

  const fetchArtists = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (langFilter !== "all") params.append("language", langFilter);
      if (selectedGenre !== "all") params.append("genre", selectedGenre);
      params.append("limit", "250");

      const res = await fetch(`/api/artists?${params.toString()}`);
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setArtists(data.data);
      }
    } catch (err) {
      console.error("Error loading artists:", err);
    } finally {
      setLoading(false);
    }
  };

  const filteredArtists = artists.filter((a) => {
    const term = search.toLowerCase();
    return a.name.toLowerCase().includes(term) || (a.nameAr && a.nameAr.toLowerCase().includes(term));
  });

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-zinc-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
            <Mic2 className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white">دليل الفنانين والنجوم ({artists.length})</h1>
            <p className="text-xs sm:text-sm text-zinc-400">
              تصفح عمالقة الطرب والبوب والراب والخليجي والشعبي والعالمي
            </p>
          </div>
        </div>

        {/* Language Filter */}
        <div className="flex items-center bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs">
          <button
            onClick={() => setLangFilter("all")}
            className={`px-3 py-1.5 rounded-lg transition font-medium ${
              langFilter === "all" ? "bg-emerald-500 text-zinc-950 font-bold" : "text-zinc-400 hover:text-white"
            }`}
          >
            الكل
          </button>
          <button
            onClick={() => setLangFilter("arabic")}
            className={`px-3 py-1.5 rounded-lg transition font-medium ${
              langFilter === "arabic" ? "bg-emerald-500 text-zinc-950 font-bold" : "text-zinc-400 hover:text-white"
            }`}
          >
            عربي
          </button>
          <button
            onClick={() => setLangFilter("international")}
            className={`px-3 py-1.5 rounded-lg transition font-medium ${
              langFilter === "international" ? "bg-emerald-500 text-zinc-950 font-bold" : "text-zinc-400 hover:text-white"
            }`}
          >
            عالمي
          </button>
        </div>
      </div>

      {/* Genre Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {GENRE_CHIPS.map((chip) => (
          <button
            key={chip.id}
            onClick={() => setSelectedGenre(chip.id)}
            className={`px-3.5 py-1.5 rounded-xl shrink-0 transition font-semibold border ${
              selectedGenre === chip.id
                ? "bg-emerald-500 text-zinc-950 border-emerald-400 shadow-md shadow-emerald-500/20"
                : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white hover:border-zinc-700"
            }`}
          >
            {chip.label}
          </button>
        ))}
      </div>

      {/* Filter / Search Bar */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-zinc-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث باسم الفنان (مثل: عمرو دياب، فيروز، كولدبلاي، كاظم الساهر)..."
          className="w-full bg-zinc-900 text-sm text-white placeholder-zinc-500 rounded-xl pr-10 pl-4 py-2.5 border border-zinc-800 focus:border-emerald-500 outline-none"
        />
      </div>

      {/* Artists Grid */}
      {loading ? (
        <div className="p-12 text-center text-zinc-500">جاري تحميل الفنانين...</div>
      ) : filteredArtists.length === 0 ? (
        <div className="p-12 text-center bg-zinc-900/50 rounded-2xl border border-zinc-800">
          <p className="text-zinc-400">لا يوجد فنان يطابق بحثك.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filteredArtists.map((artist) => (
            <ArtistCard key={artist.id} artist={artist} />
          ))}
        </div>
      )}
    </div>
  );
}
