import { NextRequest, NextResponse } from "next/server";
import { getAlbums } from "@/lib/music-service";
import { GenreCategory, MusicLanguage } from "@/lib/types";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const genre = (searchParams.get("genre") as GenreCategory) || undefined;
    const language = (searchParams.get("language") as MusicLanguage) || undefined;
    const limit = searchParams.get("limit") ? parseInt(searchParams.get("limit")!, 10) : 30;

    const albumsList = await getAlbums({
      genreCategory: genre,
      language: language,
      limit: Math.min(limit, 250),
    });

    return NextResponse.json({
      success: true,
      count: albumsList.length,
      data: albumsList,
    });
  } catch (error: any) {
    console.error("GET /api/albums error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
