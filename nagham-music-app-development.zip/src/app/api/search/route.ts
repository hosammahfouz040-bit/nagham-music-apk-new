import { NextRequest, NextResponse } from "next/server";
import { performGlobalSearch } from "@/lib/music-service";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q") || "";

    if (!query.trim()) {
      return NextResponse.json({
        success: true,
        data: { tracks: [], artists: [], albums: [], playlists: [], totalResults: 0 },
      });
    }

    const searchResults = await performGlobalSearch(query);

    return NextResponse.json({
      success: true,
      query: query,
      data: searchResults,
    });
  } catch (error: any) {
    console.error("GET /api/search error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
