import { NextRequest, NextResponse } from "next/server";
import { getArtistDetails } from "@/lib/music-service";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const result = await getArtistDetails(id);

    if (!result.artist && result.tracks.length === 0) {
      return NextResponse.json({ success: false, error: "Artist not found" }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: result,
    });
  } catch (error: any) {
    console.error("GET /api/artists/[id] error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
