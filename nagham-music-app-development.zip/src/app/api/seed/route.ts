import { NextResponse } from "next/server";
import { seedDatabaseIfEmpty } from "@/lib/seed-db";

export async function POST() {
  try {
    const result = await seedDatabaseIfEmpty();
    return NextResponse.json(result);
  } catch (error: any) {
    console.error("POST /api/seed error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function GET() {
  try {
    const result = await seedDatabaseIfEmpty();
    return NextResponse.json(result);
  } catch (error: any) {
    console.error("GET /api/seed error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
