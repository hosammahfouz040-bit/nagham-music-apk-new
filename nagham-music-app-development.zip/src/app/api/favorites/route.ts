import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { favorites } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { GenreCategory, TrackPlaybackType } from "@/lib/types";

export async function GET() {
  try {
    const rows = await db.select().from(favorites).orderBy(desc(favorites.createdAt));
    return NextResponse.json({
      success: true,
      count: rows.length,
      data: rows.map((r) => ({
        id: r.trackId,
        trackId: r.trackId,
        title: r.title,
        artistName: r.artistName,
        albumName: r.albumName || "",
        artworkUrl: r.artworkUrl || "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600",
        previewUrl: r.previewUrl,
        youtubeVideoId: r.youtubeVideoId,
        fullStreamUrl: r.fullStreamUrl,
        isFullPlayable: r.isFullPlayable,
        fullDurationSeconds: r.fullDurationSeconds,
        playbackType: (r.playbackType as TrackPlaybackType) || "preview_only",
        durationSeconds: r.durationSeconds || 30,
        genre: r.genre || "موسيقى",
        genreCategory: (r.genreCategory as GenreCategory) || "pop",
        language: (r.language as "arabic" | "international") || "arabic",
        externalAppleMusicUrl: r.externalAppleMusicUrl,
        externalDeezerUrl: r.externalDeezerUrl,
        externalSpotifyUrl: r.externalSpotifyUrl,
        externalYoutubeUrl: r.externalYoutubeUrl,
        externalAnghamiUrl: r.externalAnghamiUrl,
      })),
    });
  } catch (error: any) {
    console.error("GET /api/favorites error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      trackId,
      title,
      artistName,
      albumName,
      artworkUrl,
      previewUrl,
      youtubeVideoId,
      fullStreamUrl,
      isFullPlayable,
      fullDurationSeconds,
      playbackType,
      durationSeconds,
      genre,
      genreCategory,
      language,
      externalAppleMusicUrl,
      externalDeezerUrl,
      externalSpotifyUrl,
      externalYoutubeUrl,
      externalAnghamiUrl,
    } = body;

    if (!trackId || !title || !previewUrl) {
      return NextResponse.json({ success: false, error: "بيانات الأغنية غير مكتملة" }, { status: 400 });
    }

    const existing = await db.select().from(favorites).where(eq(favorites.trackId, trackId)).limit(1);

    if (existing.length > 0) {
      await db.delete(favorites).where(eq(favorites.trackId, trackId));
      return NextResponse.json({ success: true, isFavorite: false, message: "تمت إزالة الأغنية من المفضلة" });
    } else {
      await db.insert(favorites).values({
        trackId,
        title,
        artistName: artistName || "فنان غير معروف",
        albumName: albumName || "",
        artworkUrl: artworkUrl || "",
        previewUrl,
        youtubeVideoId: youtubeVideoId || null,
        fullStreamUrl: fullStreamUrl || null,
        isFullPlayable: !!isFullPlayable,
        fullDurationSeconds: fullDurationSeconds || null,
        playbackType: playbackType || "preview_only",
        durationSeconds: durationSeconds || 30,
        genre: genre || "موسيقى",
        genreCategory: genreCategory || "pop",
        language: language || "arabic",
        externalAppleMusicUrl,
        externalDeezerUrl,
        externalSpotifyUrl,
        externalYoutubeUrl,
        externalAnghamiUrl,
      });
      return NextResponse.json({ success: true, isFavorite: true, message: "تمت إضافة الأغنية إلى المفضلة" });
    }
  } catch (error: any) {
    console.error("POST /api/favorites error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
