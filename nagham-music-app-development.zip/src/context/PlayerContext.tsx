"use client";

import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from "react";
import { Track, ActivePlayerMode } from "@/lib/types";

// YouTube IFrame API Global Type
declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

interface PlayerContextType {
  currentTrack: Track | null;
  activeMode: ActivePlayerMode;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: "off" | "all" | "one";
  playbackRate: number;
  queue: Track[];
  queueIndex: number;
  favoritesSet: Set<string>;
  sleepTimerMinutes: number | null;
  sleepTimerRemaining: number | null;
  isFullPlayerOpen: boolean;
  isSourceModalOpen: boolean;
  sourceModalTrack: Track | null;
  playTrack: (track: Track, newQueue?: Track[], preferredMode?: ActivePlayerMode) => void;
  switchMode: (newMode: ActivePlayerMode) => void;
  pause: () => void;
  resume: () => void;
  togglePlay: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  seek: (seconds: number) => void;
  setVolumeLevel: (vol: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  setSpeed: (rate: number) => void;
  setSleepTimer: (minutes: number | null) => void;
  addToQueue: (track: Track) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;
  toggleFavorite: (track: Track) => Promise<boolean>;
  isFavorite: (trackId: string) => boolean;
  openFullPlayer: () => void;
  closeFullPlayer: () => void;
  openSourceModal: (track?: Track) => void;
  closeSourceModal: () => void;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  youtubeContainerRef: React.RefObject<HTMLDivElement | null>;
  activeEngine: "audio" | "youtube";
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [activeMode, setActiveMode] = useState<ActivePlayerMode>("full");
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(240);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<"off" | "all" | "one">("off");
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [queue, setQueue] = useState<Track[]>([]);
  const [queueIndex, setQueueIndex] = useState<number>(0);
  const [favoritesSet, setFavoritesSet] = useState<Set<string>>(new Set());
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null);
  const [isFullPlayerOpen, setIsFullPlayerOpen] = useState<boolean>(false);
  const [isSourceModalOpen, setIsSourceModalOpen] = useState<boolean>(false);
  const [sourceModalTrack, setSourceModalTrack] = useState<Track | null>(null);
  const [activeEngine, setActiveEngine] = useState<"audio" | "youtube">("youtube");

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ytPlayerRef = useRef<any>(null);
  const youtubeContainerRef = useRef<HTMLDivElement | null>(null);
  const ytIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const historyLoggedRef = useRef<string | null>(null);
  const isYtApiReadyRef = useRef<boolean>(false);
  const currentResolvingTrackIdRef = useRef<string | null>(null);

  // Initialize YouTube IFrame API script
  useEffect(() => {
    if (typeof window === "undefined") return;

    if (!window.YT) {
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      const firstScriptTag = document.getElementsByTagName("script")[0];
      firstScriptTag?.parentNode?.insertBefore(tag, firstScriptTag);

      window.onYouTubeIframeAPIReady = () => {
        isYtApiReadyRef.current = true;
      };
    } else {
      isYtApiReadyRef.current = true;
    }
  }, []);

  // Initialize HTML5 Audio element (for fallback & instant start)
  useEffect(() => {
    if (typeof window === "undefined") return;

    const audio = new Audio();
    audio.preload = "auto";
    audio.volume = volume;
    audioRef.current = audio;

    const handleTimeUpdate = () => {
      if (activeEngine !== "audio") return;
      setCurrentTime(audio.currentTime);
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }

      if (audio.currentTime > 5 && currentTrack && historyLoggedRef.current !== currentTrack.trackId) {
        historyLoggedRef.current = currentTrack.trackId;
        logHistory(currentTrack, Math.round(audio.duration || 240));
      }
    };

    const handleLoadedMetadata = () => {
      if (activeEngine !== "audio") return;
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const handleEnded = () => {
      if (activeEngine !== "audio") return;
      if (repeatMode === "one") {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      } else {
        handleNextTrack();
      }
    };

    const handlePlay = () => {
      if (activeEngine === "audio") setIsPlaying(true);
    };
    const handlePause = () => {
      if (activeEngine === "audio") setIsPlaying(false);
    };
    const handleError = (e: any) => {
      console.warn("Audio element error:", e);
      if (activeEngine === "audio") setIsPlaying(false);
    };

    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("play", handlePlay);
    audio.addEventListener("pause", handlePause);
    audio.addEventListener("error", handleError);

    // Load initial favorites and initialize local offline IndexedDB
    import("@/lib/offline-store").then(({ initializeOfflineDatabase, getOfflineFavorites }) => {
      initializeOfflineDatabase().catch(() => {});
      getOfflineFavorites().then((favs) => {
        if (favs.length > 0) {
          setFavoritesSet(new Set(favs.map((f) => f.trackId)));
        }
      }).catch(() => {});
    });

    fetch("/api/favorites")
      .then((r) => r.json())
      .then((d) => {
        if (d.success && Array.isArray(d.data)) {
          setFavoritesSet(new Set(d.data.map((fav: any) => fav.trackId)));
        }
      })
      .catch(() => {});

    return () => {
      audio.pause();
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("play", handlePlay);
      audio.removeEventListener("pause", handlePause);
      audio.removeEventListener("error", handleError);
    };
  }, [activeEngine, currentTrack, repeatMode]);

  const logHistory = (track: Track, durationSec: number) => {
    fetch("/api/history", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        trackId: track.trackId,
        title: track.title,
        artistName: track.artistName,
        albumName: track.albumName,
        artworkUrl: track.artworkUrl,
        previewUrl: track.previewUrl,
        durationSeconds: durationSec,
        genre: track.genre,
      }),
    }).catch(() => {});
  };

  // YouTube Polling Timer for continuous timeupdate & full duration
  const startYouTubeTimePolling = () => {
    if (ytIntervalRef.current) clearInterval(ytIntervalRef.current);

    ytIntervalRef.current = setInterval(() => {
      if (ytPlayerRef.current && typeof ytPlayerRef.current.getCurrentTime === "function") {
        try {
          const cur = ytPlayerRef.current.getCurrentTime() || 0;
          const dur = ytPlayerRef.current.getDuration() || 0;
          setCurrentTime(cur);
          if (dur > 0) setDuration(dur);

          if (cur > 5 && currentTrack && historyLoggedRef.current !== currentTrack.trackId) {
            historyLoggedRef.current = currentTrack.trackId;
            logHistory(currentTrack, Math.round(dur || 240));
          }
        } catch {
          // ignore
        }
      }
    }, 400);
  };

  const stopYouTubeTimePolling = () => {
    if (ytIntervalRef.current) {
      clearInterval(ytIntervalRef.current);
      ytIntervalRef.current = null;
    }
  };

  // Sleep Timer interval
  useEffect(() => {
    if (sleepTimerMinutes === null) {
      setSleepTimerRemaining(null);
      return;
    }

    setSleepTimerRemaining(sleepTimerMinutes * 60);

    const interval = setInterval(() => {
      setSleepTimerRemaining((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          pause();
          setIsPlaying(false);
          setSleepTimerMinutes(null);
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerMinutes]);

  // MediaSession API setup for Android lock screen & notifications
  useEffect(() => {
    if (typeof window === "undefined" || !("mediaSession" in navigator) || !currentTrack) return;

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: currentTrack.title,
        artist: currentTrack.artistName,
        album: currentTrack.albumName || "نغم | Nagham",
        artwork: [
          { src: currentTrack.artworkUrl, sizes: "96x96", type: "image/jpeg" },
          { src: currentTrack.artworkUrl, sizes: "256x256", type: "image/jpeg" },
          { src: currentTrack.artworkUrl, sizes: "512x512", type: "image/jpeg" },
        ],
      });

      navigator.mediaSession.setActionHandler("play", () => resume());
      navigator.mediaSession.setActionHandler("pause", () => pause());
      navigator.mediaSession.setActionHandler("nexttrack", () => nextTrack());
      navigator.mediaSession.setActionHandler("previoustrack", () => prevTrack());
      navigator.mediaSession.setActionHandler("seekto", (details) => {
        if (details.seekTime !== undefined) seek(details.seekTime);
      });
    } catch (e) {
      console.warn("MediaSession setup error:", e);
    }
  }, [currentTrack]);

  // Play YouTube Video in full length
  const playYouTubeVideo = (videoId: string, targetDuration?: number, startSeconds: number = 0) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }

    setActiveEngine("youtube");
    setDuration(targetDuration || 240);
    if (startSeconds > 0) setCurrentTime(startSeconds);

    const onPlayerStateChange = (event: any) => {
      // 1 = PLAYING, 2 = PAUSED, 0 = ENDED
      if (event.data === 1) {
        setIsPlaying(true);
        startYouTubeTimePolling();
      } else if (event.data === 2) {
        setIsPlaying(false);
      } else if (event.data === 0) {
        if (repeatMode === "one") {
          ytPlayerRef.current?.seekTo(0, true);
          ytPlayerRef.current?.playVideo();
        } else {
          handleNextTrack();
        }
      }
    };

    if (!ytPlayerRef.current && window.YT && window.YT.Player) {
      ytPlayerRef.current = new window.YT.Player("nagham-yt-player-element", {
        height: "100%",
        width: "100%",
        videoId: videoId,
        playerVars: {
          autoplay: 1,
          controls: 0,
          modestbranding: 1,
          rel: 0,
          playsinline: 1,
          start: Math.floor(startSeconds),
          origin: window.location.origin,
        },
        events: {
          onReady: (event: any) => {
            event.target.setVolume(isMuted ? 0 : Math.round(volume * 100));
            if (startSeconds > 0) event.target.seekTo(startSeconds, true);
            event.target.playVideo();
            setIsPlaying(true);
            startYouTubeTimePolling();
          },
          onStateChange: onPlayerStateChange,
        },
      });
    } else if (ytPlayerRef.current && typeof ytPlayerRef.current.loadVideoById === "function") {
      ytPlayerRef.current.loadVideoById({
        videoId: videoId,
        startSeconds: Math.floor(startSeconds),
      });
      ytPlayerRef.current.setVolume(isMuted ? 0 : Math.round(volume * 100));
      ytPlayerRef.current.playVideo();
      setIsPlaying(true);
      startYouTubeTimePolling();
    }
  };

  const playAudioStream = (url: string, targetDuration?: number) => {
    if (ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === "function") {
      ytPlayerRef.current.pauseVideo();
    }
    stopYouTubeTimePolling();

    setActiveEngine("audio");
    setDuration(targetDuration || 240);
    setCurrentTime(0);

    if (audioRef.current) {
      audioRef.current.src = url;
      audioRef.current.playbackRate = playbackRate;
      audioRef.current.volume = isMuted ? 0 : volume;
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((err) => {
          console.warn("Audio autoplay error:", err);
          setIsPlaying(false);
        });
    }
  };

  const playTrack = (track: Track, newQueue?: Track[], preferredMode?: ActivePlayerMode) => {
    if (!track) return;

    setCurrentTrack(track);
    historyLoggedRef.current = null;
    currentResolvingTrackIdRef.current = track.trackId;

    if (newQueue && newQueue.length > 0) {
      setQueue(newQueue);
      const index = newQueue.findIndex((t) => t.trackId === track.trackId);
      setQueueIndex(index >= 0 ? index : 0);
    } else if (queue.length === 0) {
      setQueue([track]);
      setQueueIndex(0);
    }

    setActiveMode("full");

    // Case 1: Video ID already known -> play immediately via YouTube
    if (track.youtubeVideoId) {
      playYouTubeVideo(track.youtubeVideoId, track.fullDurationSeconds || 240);
      return;
    }

    // Case 2: Full direct stream available
    if (track.fullStreamUrl) {
      playAudioStream(track.fullStreamUrl, track.fullDurationSeconds || 240);
      return;
    }

    // Case 3: Start instant audio preview for 0ms latency, while resolving full video ID in background
    if (track.previewUrl) {
      playAudioStream(track.previewUrl, track.fullDurationSeconds || 240);
    }

    // Resolve full video ID in background and seamlessly switch to full player
    fetch(
      `/api/resolve-youtube?title=${encodeURIComponent(track.title)}&artist=${encodeURIComponent(
        track.artistName
      )}&trackId=${encodeURIComponent(track.trackId)}`
    )
      .then((r) => r.json())
      .then((data) => {
        if (data.success && data.youtubeVideoId) {
          track.youtubeVideoId = data.youtubeVideoId;
          track.fullDurationSeconds = data.fullDurationSeconds || 240;
          track.isFullPlayable = true;

          // If this is still the active track playing, seamlessly upgrade to full YouTube stream
          if (currentResolvingTrackIdRef.current === track.trackId) {
            const currentAudioTime = audioRef.current?.currentTime || 0;
            playYouTubeVideo(data.youtubeVideoId, data.fullDurationSeconds || 240, currentAudioTime);
          }
        }
      })
      .catch((err) => {
        console.warn("Could not resolve YouTube full ID:", err);
      });
  };

  const switchMode = (newMode: ActivePlayerMode) => {
    if (!currentTrack) return;
    setActiveMode(newMode);
    if (newMode === "full" && currentTrack.youtubeVideoId) {
      playYouTubeVideo(currentTrack.youtubeVideoId, currentTrack.fullDurationSeconds || 240, currentTime);
    } else if (currentTrack.previewUrl) {
      playAudioStream(currentTrack.previewUrl, 30);
    }
  };

  const pause = () => {
    if (activeEngine === "youtube" && ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === "function") {
      ytPlayerRef.current.pauseVideo();
    } else if (audioRef.current) {
      audioRef.current.pause();
    }
    setIsPlaying(false);
  };

  const resume = () => {
    if (activeEngine === "youtube" && ytPlayerRef.current && typeof ytPlayerRef.current.playVideo === "function") {
      ytPlayerRef.current.playVideo();
      setIsPlaying(true);
    } else if (audioRef.current && currentTrack) {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((err) => console.warn("Audio play failed:", err));
    }
  };

  const togglePlay = () => {
    if (isPlaying) {
      pause();
    } else {
      resume();
    }
  };

  const handleNextTrack = () => {
    if (queue.length === 0) return;

    let nextIdx: number;
    if (isShuffle) {
      nextIdx = Math.floor(Math.random() * queue.length);
    } else {
      nextIdx = queueIndex + 1;
      if (nextIdx >= queue.length) {
        if (repeatMode === "all") {
          nextIdx = 0;
        } else {
          setIsPlaying(false);
          return;
        }
      }
    }

    setQueueIndex(nextIdx);
    const nextT = queue[nextIdx];
    if (nextT) {
      playTrack(nextT, undefined, "full");
    }
  };

  const nextTrack = () => handleNextTrack();

  const prevTrack = () => {
    if (queue.length === 0) return;

    if (currentTime > 3) {
      seek(0);
      return;
    }

    let prevIdx = queueIndex - 1;
    if (prevIdx < 0) {
      prevIdx = repeatMode === "all" ? queue.length - 1 : 0;
    }

    setQueueIndex(prevIdx);
    const prevT = queue[prevIdx];
    if (prevT) {
      playTrack(prevT, undefined, "full");
    }
  };

  const seek = (seconds: number) => {
    const clamped = Math.max(0, Math.min(seconds, duration));
    setCurrentTime(clamped);

    if (activeEngine === "youtube" && ytPlayerRef.current && typeof ytPlayerRef.current.seekTo === "function") {
      ytPlayerRef.current.seekTo(clamped, true);
    } else if (audioRef.current) {
      audioRef.current.currentTime = clamped;
    }
  };

  const setVolumeLevel = (vol: number) => {
    const clamped = Math.max(0, Math.min(1, vol));
    setVolume(clamped);
    setIsMuted(clamped === 0);

    if (activeEngine === "youtube" && ytPlayerRef.current && typeof ytPlayerRef.current.setVolume === "function") {
      ytPlayerRef.current.setVolume(Math.round(clamped * 100));
    }
    if (audioRef.current) {
      audioRef.current.volume = clamped;
    }
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      const targetVol = volume > 0 ? volume : 0.85;
      if (activeEngine === "youtube" && ytPlayerRef.current) {
        ytPlayerRef.current.unMute();
        ytPlayerRef.current.setVolume(Math.round(targetVol * 100));
      }
      if (audioRef.current) audioRef.current.volume = targetVol;
    } else {
      setIsMuted(true);
      if (activeEngine === "youtube" && ytPlayerRef.current) {
        ytPlayerRef.current.mute();
      }
      if (audioRef.current) audioRef.current.volume = 0;
    }
  };

  const toggleShuffle = () => setIsShuffle(!isShuffle);

  const toggleRepeat = () => {
    if (repeatMode === "off") setRepeatMode("all");
    else if (repeatMode === "all") setRepeatMode("one");
    else setRepeatMode("off");
  };

  const setSpeed = (rate: number) => {
    setPlaybackRate(rate);
    if (activeEngine === "youtube" && ytPlayerRef.current && typeof ytPlayerRef.current.setPlaybackRate === "function") {
      ytPlayerRef.current.setPlaybackRate(rate);
    }
    if (audioRef.current) {
      audioRef.current.playbackRate = rate;
    }
  };

  const setSleepTimer = (minutes: number | null) => {
    setSleepTimerMinutes(minutes);
  };

  const addToQueue = (track: Track) => {
    setQueue((prev) => [...prev, track]);
  };

  const removeFromQueue = (index: number) => {
    setQueue((prev) => prev.filter((_, i) => i !== index));
    if (index === queueIndex && queue.length > 1) {
      nextTrack();
    }
  };

  const clearQueue = () => {
    if (currentTrack) {
      setQueue([currentTrack]);
      setQueueIndex(0);
    } else {
      setQueue([]);
      setQueueIndex(0);
    }
  };

  const toggleFavorite = async (track: Track): Promise<boolean> => {
    try {
      const isFav = favoritesSet.has(track.trackId);
      const res = await fetch("/api/favorites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(track),
      });
      const data = await res.json();
      if (data.success) {
        setFavoritesSet((prev) => {
          const next = new Set(prev);
          if (data.isFavorite) {
            next.add(track.trackId);
          } else {
            next.delete(track.trackId);
          }
          return next;
        });
        return data.isFavorite;
      }
      return !isFav;
    } catch {
      return false;
    }
  };

  const isFavorite = (trackId: string): boolean => {
    return favoritesSet.has(trackId);
  };

  const openFullPlayer = () => setIsFullPlayerOpen(true);
  const closeFullPlayer = () => setIsFullPlayerOpen(false);

  const openSourceModal = (track?: Track) => {
    setSourceModalTrack(track || currentTrack);
    setIsSourceModalOpen(true);
  };

  const closeSourceModal = () => {
    setIsSourceModalOpen(false);
    setSourceModalTrack(null);
  };

  return (
    <PlayerContext.Provider
      value={{
        currentTrack,
        activeMode,
        isPlaying,
        currentTime,
        duration,
        volume,
        isMuted,
        isShuffle,
        repeatMode,
        playbackRate,
        queue,
        queueIndex,
        favoritesSet,
        sleepTimerMinutes,
        sleepTimerRemaining,
        isFullPlayerOpen,
        isSourceModalOpen,
        sourceModalTrack,
        playTrack,
        switchMode,
        pause,
        resume,
        togglePlay,
        nextTrack,
        prevTrack,
        seek,
        setVolumeLevel,
        toggleMute,
        toggleShuffle,
        toggleRepeat,
        setSpeed,
        setSleepTimer,
        addToQueue,
        removeFromQueue,
        clearQueue,
        toggleFavorite,
        isFavorite,
        openFullPlayer,
        closeFullPlayer,
        openSourceModal,
        closeSourceModal,
        audioRef,
        youtubeContainerRef,
        activeEngine,
      }}
    >
      {/* Hidden YouTube IFrame container for official full song playback */}
      <div
        ref={youtubeContainerRef}
        style={{
          position: "fixed",
          top: "-9999px",
          left: "-9999px",
          width: "200px",
          height: "200px",
          opacity: 0,
          pointerEvents: "none",
          zIndex: -1,
        }}
        aria-hidden="true"
      >
        <div id="nagham-yt-player-element" />
      </div>

      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error("usePlayer must be used within a PlayerProvider");
  }
  return context;
}
